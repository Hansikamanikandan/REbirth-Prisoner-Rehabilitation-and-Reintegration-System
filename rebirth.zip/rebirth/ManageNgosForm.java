package rebirth;

import java.awt.*;
import java.sql.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Administrator: register NGO partner accounts, correct their contact
 * details, reset a password or remove an NGO. The table also shows how much
 * assistance each NGO has recorded (from Provide Assistance), so the
 * administrator can see which partners are active.
 *
 * An NGO is a USERS row whose role is NGO (same as registration).
 * The "Centres and Partners" button opens the list that feeds the map.
 */
public class ManageNgosForm extends JFrame {

    private final String fullName;
    private final String role;
    private String roleCol = "ROLE";
    private String ngoRole = "NGO";

    private final JTextField search = Theme.field();
    private final JTextField name = Theme.field();
    private final JTextField username = Theme.field();
    private final JTextField email = Theme.field();
    private final JTextField phone = Theme.field();
    private final JPasswordField password = AdminUtil.passwordField();
    private final JLabel summary = new JLabel(" ");

    private final DefaultTableModel model = CounsellorUtil.readOnlyModel(
        "ID", "Organisation", "Username", "Email", "Phone",
        "Assistance Records", "People Helped");
    private final JTable table = CounsellorUtil.table(model);

    public ManageNgosForm(int userId, String fullName, String role) {

        this.fullName = fullName;
        this.role = role;

        setTitle("REbirth - Manage NGOs");
        FrameFit.maximize(this);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        table.getColumnModel().getColumn(0).setMaxWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);
        table.getColumnModel().getColumn(2).setPreferredWidth(140);
        table.getColumnModel().getColumn(3).setPreferredWidth(220);
        table.getColumnModel().getColumn(4).setPreferredWidth(110);
        table.getColumnModel().getColumn(5).setPreferredWidth(130);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);

        try (Connection con = DBConnection.getConnection()) {
            roleCol = AdminUtil.roleColumn(con);
            List<String> roles = AdminUtil.roles(con, roleCol);
            ngoRole = AdminUtil.roleSpelling(roles, false);
            ProvideAssistanceForm.ensureTable(con);
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }

        JPanel root = new Theme.Backdrop(new BorderLayout());
        root.add(new Theme.HeaderBand("Manage NGOs",
            "Welcome, " + fullName + "  |  Role: " + role), BorderLayout.NORTH);

        JPanel card = CounsellorUtil.formCard();
        CounsellorUtil.addRow(card, 0, "Organisation", name);
        CounsellorUtil.addRow(card, 1, "Username", username);
        CounsellorUtil.addRow(card, 2, "Email", email);
        CounsellorUtil.addRow(card, 3, "Phone", phone);
        CounsellorUtil.addRow(card, 4, "Password", password);
        CounsellorUtil.addRow(card, 5, "", Theme.text(
            "Password is used for Add NGO and Reset Password only. "
            + "Leave it empty when you update contact details.",
            620, 12, Theme.MUTED));

        Theme.Button go = new Theme.Button("Search", Theme.GREEN_DARK, Color.WHITE);
        go.addActionListener(e -> load());
        search.addActionListener(e -> load());

        JPanel middle = new JPanel(new BorderLayout(0, 10));
        middle.setOpaque(false);
        middle.add(AdminUtil.searchRow(search, null, go), BorderLayout.NORTH);
        middle.add(CounsellorUtil.scroll(table), BorderLayout.CENTER);

        summary.setFont(Theme.f(Font.BOLD, 13));
        summary.setForeground(Theme.GREEN_DARK);
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(buildButtons(), BorderLayout.WEST);
        south.add(summary, BorderLayout.EAST);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        body.add(card, BorderLayout.NORTH);
        body.add(middle, BorderLayout.CENTER);
        body.add(south, BorderLayout.SOUTH);

        root.add(FrameFit.scrollable(body), BorderLayout.CENTER);
        setContentPane(root);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFromRow();
            }
        });

        load();
    }

    private JPanel buildButtons() {

        Theme.Button add = new Theme.Button("Add NGO", Theme.GREEN, Color.WHITE);
        Theme.Button update = new Theme.Button("Update Selected",
            Theme.GREEN_DARK, Color.WHITE);
        Theme.Button reset = new Theme.Button("Reset Password",
            Theme.ORANGE, Color.WHITE);
        Theme.Button delete = new Theme.Button("Remove NGO",
            Theme.RED, Color.WHITE);
        Theme.Button clear = new Theme.Button("Clear",
            new Color(180, 120, 145), Color.WHITE);
        Theme.Button centres = new Theme.Button("Centres and Partners",
            new Color(43, 108, 176), Color.WHITE);
        Theme.Button refresh = new Theme.Button("Refresh",
            new Color(120, 130, 150), Color.WHITE);

        add.addActionListener(e -> addNgo());
        update.addActionListener(e -> updateNgo());
        reset.addActionListener(e -> resetPassword());
        delete.addActionListener(e -> removeNgo());
        clear.addActionListener(e -> clearForm());
        centres.addActionListener(e ->
            new CentresForm(fullName, role, null).setVisible(true));
        refresh.addActionListener(e -> load());

        return CounsellorUtil.buttonRow(add, update, reset, delete, clear,
            centres, refresh);
    }

    // ------------------------------------------------------------------
    private void load() {

        model.setRowCount(0);
        String like = "%" + search.getText().trim().toUpperCase() + "%";

        String sql = "SELECT u.USER_ID, u.FULL_NAME, u.USERNAME, u.EMAIL, u.PHONE, "
            + "(SELECT COUNT(*) FROM ASSISTANCE_RECORDS a "
            + "  WHERE a.NGO_USER_ID = u.USER_ID), "
            + "(SELECT COUNT(DISTINCT a.PRISONER_ID) FROM ASSISTANCE_RECORDS a "
            + "  WHERE a.NGO_USER_ID = u.USER_ID) "
            + "FROM USERS u WHERE UPPER(u." + roleCol + ") = 'NGO' "
            + "AND (UPPER(NVL(u.FULL_NAME, ' ')) LIKE ? "
            + "OR UPPER(NVL(u.USERNAME, ' ')) LIKE ? "
            + "OR UPPER(NVL(u.EMAIL, ' ')) LIKE ?) "
            + "ORDER BY u.FULL_NAME";

        int active = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (rs.getInt(6) > 0) {
                        active++;
                    }
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        Theme.nz(rs.getString(4)), Theme.nz(rs.getString(5)),
                        rs.getInt(6), rs.getInt(7)
                    });
                }
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
        summary.setText(model.getRowCount() + " NGOs  |  " + active
            + " have recorded assistance");
        clearForm();
    }

    private void fillFromRow() {

        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        name.setText(String.valueOf(model.getValueAt(row, 1)));
        username.setText(String.valueOf(model.getValueAt(row, 2)));
        email.setText(String.valueOf(model.getValueAt(row, 3)));
        phone.setText(String.valueOf(model.getValueAt(row, 4)));
        password.setText("");
        username.setEditable(false);
    }

    private void clearForm() {
        table.clearSelection();
        name.setText("");
        username.setText("");
        email.setText("");
        phone.setText("");
        password.setText("");
        username.setEditable(true);
    }

    // ------------------------------------------------------------------
    private void addNgo() {

        String n = name.getText().trim();
        String u = username.getText().trim();
        String em = email.getText().trim();
        String ph = phone.getText().trim();
        String pw = new String(password.getPassword());

        String problem = AdminUtil.checkContact(n, em, ph);
        if (problem == null) {
            problem = AdminUtil.checkUsername(u);
        }
        if (problem == null) {
            problem = AdminUtil.checkPassword(pw);
        }
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            if (AdminUtil.usernameTaken(con, u)) {
                CounsellorUtil.error(this, "That username is already taken.");
                return;
            }
            AdminUtil.insertUser(con, roleCol, n, u, pw, em, ph, ngoRole);
            CounsellorUtil.info(this, n + " has been registered as an NGO.");
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void updateNgo() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select an NGO from the table.");
            return;
        }
        String n = name.getText().trim();
        String em = email.getText().trim();
        String ph = phone.getText().trim();
        String problem = AdminUtil.checkContact(n, em, ph);
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }

        int id = (Integer) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            AdminUtil.updateContact(con, id, n, em, ph);
            CounsellorUtil.info(this, "NGO updated.");
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void resetPassword() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select an NGO from the table.");
            return;
        }
        String pw = new String(password.getPassword());
        String problem = AdminUtil.checkPassword(pw);
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this,
            "Set a new password for " + model.getValueAt(row, 1) + "?",
            "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        int id = (Integer) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            AdminUtil.resetPassword(con, id, pw);
            password.setText("");
            CounsellorUtil.info(this, "Password changed.");
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void removeNgo() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select an NGO from the table.");
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this,
            "Remove " + model.getValueAt(row, 1) + " from REbirth?\n"
            + "Its login will stop working.",
            "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        int id = (Integer) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            AdminUtil.deleteUser(con, id);
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }
}