package rebirth;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;
import javax.swing.*;

/**
 * Pop-up calendar for date fields.
 *
 *   DatePicker.wrap(field, true)   -> the field plus a calendar button
 *   DatePicker.pick(parent, initial, pastOnly) -> chosen date or null
 *
 * The chosen date is written into the text field as yyyy-MM-dd, which is the
 * format the registration form already validates. pastOnly = true greys out
 * every future day (for dates like "release date").
 */
public final class DatePicker {

    private DatePicker() { }

    private static final Color GREEN = new Color(34, 120, 84);
    private static final Color GREEN_DARK = new Color(22, 90, 62);
    private static final Color GREEN_SOFT = new Color(222, 240, 230);
    private static final Color TEXT = new Color(32, 45, 40);
    private static final Color MUTED = new Color(150, 165, 157);

    /** Field + calendar button side by side. */
    public static JComponent wrap(JTextField field, boolean pastOnly) {

        JPanel p = new JPanel(new BorderLayout(8, 0));
        p.setOpaque(false);
        p.add(field, BorderLayout.CENTER);

        JButton b = new JButton() {
            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
                g.setPaint(new GradientPaint(0, 0,
                    getModel().isRollover() ? new Color(46, 150, 104) : GREEN,
                    0, getHeight(), GREEN_DARK));
                g.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 14, 14));
                // little calendar icon
                int w = getWidth();
                int h = getHeight();
                int x = w / 2 - 10;
                int y = h / 2 - 10;
                g.setColor(Color.WHITE);
                g.fill(new RoundRectangle2D.Double(x, y + 3, 20, 17, 4, 4));
                g.setColor(GREEN_DARK);
                g.fillRect(x + 1, y + 3, 18, 5);
                g.setColor(Color.WHITE);
                g.fill(new RoundRectangle2D.Double(x + 4, y, 3, 6, 2, 2));
                g.fill(new RoundRectangle2D.Double(x + 13, y, 3, 6, 2, 2));
                g.setColor(GREEN);
                for (int r = 0; r < 2; r++) {
                    for (int c = 0; c < 3; c++) {
                        g.fillRect(x + 3 + c * 6, y + 10 + r * 5, 4, 3);
                    }
                }
                g.dispose();
            }
        };
        b.setPreferredSize(new Dimension(46, 42));
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(false);
        b.setRolloverEnabled(true);
        b.setToolTipText("Pick a date from the calendar");
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> {
            LocalDate initial = parse(field.getText());
            LocalDate d = pick(b, initial, pastOnly);
            if (d != null) {
                field.setText(d.toString());
                field.requestFocusInWindow();
            }
        });
        p.add(b, BorderLayout.EAST);
        return p;
    }

    private static LocalDate parse(String s) {
        try {
            return LocalDate.parse(s.trim());
        } catch (Exception ex) {
            return null;
        }
    }

    /** Opens the calendar under the component; returns the chosen date or null. */
    public static LocalDate pick(Component anchor, LocalDate initial, boolean pastOnly) {

        Window owner = SwingUtilities.getWindowAncestor(anchor);
        JDialog dlg = new JDialog(owner, Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setUndecorated(true);
        CalendarPanel cal = new CalendarPanel(initial, pastOnly, dlg);
        dlg.setContentPane(cal);
        dlg.pack();

        Point p = anchor.getLocationOnScreen();
        Rectangle u = Theme.usableBounds(dlg);
        int x = Math.min(p.x + anchor.getWidth() - dlg.getWidth(), u.x + u.width - dlg.getWidth() - 6);
        int y = p.y + anchor.getHeight() + 6;
        if (y + dlg.getHeight() > u.y + u.height) {
            y = p.y - dlg.getHeight() - 6;
        }
        dlg.setLocation(Math.max(u.x + 6, x), Math.max(u.y + 6, y));
        dlg.addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                dlg.dispose();
            }
        });
        dlg.setVisible(true);
        return cal.result;
    }

    // ------------------------------------------------------------------
    static class CalendarPanel extends JPanel {

        private YearMonth shown;
        private final LocalDate selected;
        private final boolean pastOnly;
        private final JDialog dialog;
        LocalDate result;
        private int hoverDay = -1;

        private final JLabel title = new JLabel("", SwingConstants.CENTER);
        private final JComboBox<Integer> years = new JComboBox<>();
        private final DayGrid grid = new DayGrid();

        CalendarPanel(LocalDate initial, boolean pastOnly, JDialog dialog) {

            this.pastOnly = pastOnly;
            this.dialog = dialog;
            LocalDate today = LocalDate.now();
            LocalDate start = initial != null ? initial : today;
            if (pastOnly && start.isAfter(today)) {
                start = today;
            }
            this.selected = initial;
            this.shown = YearMonth.from(start);

            setLayout(new BorderLayout(0, 8));
            setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
            setOpaque(false);
            setPreferredSize(new Dimension(330, 360));

            // header: < Month >   [year]
            JPanel head = new JPanel(new BorderLayout(6, 0));
            head.setOpaque(false);
            head.add(navButton("\u2039", -1), BorderLayout.WEST);
            title.setFont(Theme.f(Font.BOLD, 16));
            title.setForeground(GREEN_DARK);
            head.add(title, BorderLayout.CENTER);
            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            right.setOpaque(false);
            for (int y = today.getYear() + (pastOnly ? 0 : 15); y >= 1940; y--) {
                years.addItem(y);
            }
            Theme.flat(years);
            years.setFont(Theme.f(Font.PLAIN, 12));
            years.setPreferredSize(new Dimension(96, 28));
            years.setSelectedItem(shown.getYear());
            years.addActionListener(e -> {
                Integer y = (Integer) years.getSelectedItem();
                if (y != null && y != shown.getYear()) {
                    shown = YearMonth.of(y, shown.getMonth());
                    refresh();
                }
            });
            right.add(years);
            right.add(navButton("\u203A", 1));
            head.add(right, BorderLayout.EAST);
            add(head, BorderLayout.NORTH);

            add(grid, BorderLayout.CENTER);

            // footer
            JPanel foot = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
            foot.setOpaque(false);
            Theme.Button t = new Theme.Button("Today", GREEN, Color.WHITE);
            t.addActionListener(e -> choose(today));
            Theme.Button c = new Theme.Button("Cancel", new Color(120, 130, 150), Color.WHITE);
            c.addActionListener(e -> dialog.dispose());
            foot.add(t);
            foot.add(c);
            add(foot, BorderLayout.SOUTH);

            refresh();
        }

        private JButton navButton(String s, int delta) {
            JButton b = new JButton() {
                @Override
                protected void paintComponent(Graphics g0) {
                    Graphics2D g = (Graphics2D) g0.create();
                    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                    if (getModel().isRollover()) {
                        g.setColor(GREEN_SOFT);
                        g.fill(new Ellipse2D.Double(2, 0, getWidth() - 4, getHeight()));
                    }
                    g.setColor(GREEN_DARK);
                    g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND,
                        BasicStroke.JOIN_ROUND));
                    int cx = getWidth() / 2;
                    int cy = getHeight() / 2;
                    int d = delta < 0 ? 1 : -1;
                    g.drawLine(cx + 3 * d, cy - 6, cx - 3 * d, cy);
                    g.drawLine(cx - 3 * d, cy, cx + 3 * d, cy + 6);
                    g.dispose();
                }
            };
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setContentAreaFilled(false);
            b.setRolloverEnabled(true);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setPreferredSize(new Dimension(34, 30));
            b.addActionListener(e -> {
                shown = shown.plusMonths(delta);
                if (pastOnly && shown.isAfter(YearMonth.now())) {
                    shown = YearMonth.now();
                }
                refresh();
            });
            return b;
        }

        private void refresh() {
            title.setText(shown.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH));
            Integer y = (Integer) years.getSelectedItem();
            if (y == null || y != shown.getYear()) {
                years.setSelectedItem(shown.getYear());
            }
            grid.repaint();
        }

        private void choose(LocalDate d) {
            if (pastOnly && d.isAfter(LocalDate.now())) {
                return;
            }
            result = d;
            dialog.dispose();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(0, 0, 0, 30));
            g.fill(new RoundRectangle2D.Double(2, 3, getWidth() - 3, getHeight() - 3, 22, 22));
            g.setPaint(new GradientPaint(0, 0, Color.WHITE, 0, getHeight(), new Color(240, 249, 244)));
            g.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 3, getHeight() - 4, 22, 22));
            g.setColor(new Color(150, 195, 172));
            g.setStroke(new BasicStroke(1.4f));
            g.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 3, getHeight() - 4, 22, 22));
            g.dispose();
            super.paintComponent(g0);
        }

        /** The 7 x 6 grid of days. */
        private class DayGrid extends JComponent {

            DayGrid() {
                MouseAdapter m = new MouseAdapter() {
                    @Override
                    public void mouseMoved(MouseEvent e) {
                        int h = cellAt(e.getPoint());
                        if (h != hoverDay) {
                            hoverDay = h;
                            repaint();
                        }
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        hoverDay = -1;
                        repaint();
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        int c = cellAt(e.getPoint());
                        if (c >= 0) {
                            LocalDate d = dateOf(c);
                            choose(d);
                        }
                    }
                };
                addMouseListener(m);
                addMouseMotionListener(m);
            }

            private LocalDate dateOf(int cell) {
                int offset = shown.atDay(1).getDayOfWeek().getValue() % 7; // Sunday = 0
                return shown.atDay(1).plusDays(cell - offset);
            }

            private int cellAt(Point p) {
                int top = 26;
                double cw = getWidth() / 7.0;
                double ch = (getHeight() - top) / 6.0;
                if (p.y < top) {
                    return -1;
                }
                int col = (int) (p.x / cw);
                int row = (int) ((p.y - top) / ch);
                if (col < 0 || col > 6 || row < 0 || row > 5) {
                    return -1;
                }
                int cell = row * 7 + col;
                LocalDate d = dateOf(cell);
                if (pastOnly && d.isAfter(LocalDate.now())) {
                    return -1;
                }
                return cell;
            }

            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                int top = 26;
                double cw = getWidth() / 7.0;
                double ch = (getHeight() - top) / 6.0;

                g.setFont(Theme.f(Font.BOLD, 11));
                DayOfWeek[] order = {DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
                    DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY};
                for (int c = 0; c < 7; c++) {
                    String n = order[c].getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
                    g.setColor(c == 0 ? new Color(190, 60, 60) : GREEN_DARK);
                    FontMetrics fm = g.getFontMetrics();
                    g.drawString(n, (float) (c * cw + (cw - fm.stringWidth(n)) / 2), 17);
                }

                LocalDate today = LocalDate.now();
                for (int cell = 0; cell < 42; cell++) {
                    LocalDate d = dateOf(cell);
                    int col = cell % 7;
                    int row = cell / 7;
                    double cx = col * cw + cw / 2;
                    double cy = top + row * ch + ch / 2;
                    boolean inMonth = d.getMonth() == shown.getMonth();
                    boolean future = pastOnly && d.isAfter(today);
                    boolean sel = d.equals(selected);
                    boolean hov = cell == hoverDay;
                    double r = Math.min(cw, ch) / 2 - 3;

                    if (sel) {
                        g.setPaint(new GradientPaint((float) cx, (float) (cy - r), GREEN,
                            (float) cx, (float) (cy + r), GREEN_DARK));
                        g.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
                    } else if (hov) {
                        g.setColor(GREEN_SOFT);
                        g.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
                    }
                    if (d.equals(today) && !sel) {
                        g.setColor(GREEN);
                        g.setStroke(new BasicStroke(1.8f));
                        g.draw(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
                    }
                    g.setFont(Theme.f(sel || d.equals(today) ? Font.BOLD : Font.PLAIN, 13));
                    g.setColor(sel ? Color.WHITE : future ? new Color(200, 208, 203)
                        : inMonth ? (col == 0 ? new Color(190, 60, 60) : TEXT) : MUTED);
                    String s = String.valueOf(d.getDayOfMonth());
                    FontMetrics fm = g.getFontMetrics();
                    g.drawString(s, (float) (cx - fm.stringWidth(s) / 2.0), (float) (cy + 4.5));
                }
                g.dispose();
            }
        }
    }
}