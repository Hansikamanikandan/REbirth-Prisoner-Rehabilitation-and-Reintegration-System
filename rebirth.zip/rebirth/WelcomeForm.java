package rebirth;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * The first screen of REbirth.
 *
 * A clean split-screen layout:
 *  - left : brand panel (deep green gradient, subtle sunrise rings, headline)
 *  - right: welcome text with "Log in" and "Create an account" actions
 */
public class WelcomeForm extends JFrame {

    private static final Color GREEN_DARK  = new Color(7, 48, 36);
    private static final Color GREEN_MID   = new Color(14, 88, 62);
    private static final Color GREEN_BTN   = new Color(24, 120, 76);
    private static final Color GOLD        = new Color(232, 190, 104);
    private static final Color PAGE_BG     = new Color(248, 247, 243);
    private static final Color TEXT_DARK   = new Color(26, 38, 33);
    private static final Color TEXT_MUTED  = new Color(104, 114, 108);

    public WelcomeForm() {
        setTitle("REbirth");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1000, 640));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1;

        c.gridx = 0;
        c.weightx = 0.56;
        root.add(new BrandPanel(), c);

        c.gridx = 1;
        c.weightx = 0.44;
        root.add(buildActionPanel(), c);

        setContentPane(root);
        setVisible(true);
    }

    private void goLogin() {
        dispose();
        new LoginForm();
    }

    private void goRegister() {
        dispose();
        new RegistrationForm();
    }

    // ==================================================================
    // Right side: welcome message and actions
    // ==================================================================
    private JPanel buildActionPanel() {
        JPanel page = new JPanel(new GridBagLayout());
        page.setBackground(PAGE_BG);

        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);
        col.setPreferredSize(new Dimension(380, 420));

        JLabel eyebrow = label("WELCOME", new Font("Segoe UI", Font.BOLD, 13), GREEN_BTN);
        JLabel heading = label("Sign in to continue", new Font("Segoe UI", Font.BOLD, 32), TEXT_DARK);
        JLabel sub = label("<html><body style='width:360px'>Pick up where you left off, "
            + "or create an account to begin a fresh start.</body></html>",
            new Font("Segoe UI", Font.PLAIN, 15), TEXT_MUTED);

        LoginForm.RoundedButton login = new LoginForm.RoundedButton("Log in",
            GREEN_BTN, Color.WHITE, new Color(10, 70, 44), true);
        LoginForm.RoundedButton register = new LoginForm.RoundedButton("Create an account",
            Color.WHITE, new Color(13, 75, 49), new Color(200, 206, 198), false);
        for (LoginForm.RoundedButton b : new LoginForm.RoundedButton[]{login, register}) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 16));
            b.setPreferredSize(new Dimension(380, 52));
            b.setMaximumSize(new Dimension(380, 52));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
        }
        login.addActionListener(e -> goLogin());
        register.addActionListener(e -> goRegister());

        JLabel footer = label("New here? Registration takes less than a minute.",
            new Font("Segoe UI", Font.PLAIN, 13), TEXT_MUTED);

        col.add(eyebrow);
        col.add(Box.createVerticalStrut(10));
        col.add(heading);
        col.add(Box.createVerticalStrut(14));
        col.add(sub);
        col.add(Box.createVerticalStrut(36));
        col.add(login);
        col.add(Box.createVerticalStrut(14));
        col.add(register);
        col.add(Box.createVerticalStrut(22));
        col.add(footer);

        page.add(col);
        return page;
    }

    private static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    // ==================================================================
    // Left side: brand panel
    // ==================================================================
    private static class BrandPanel extends JPanel {

        BrandPanel() {
            setOpaque(true);
            setPreferredSize(new Dimension(700, 800));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

            int w = getWidth();
            int h = getHeight();
            double u = Math.max(0.75, Math.min(w / 700.0, h / 800.0));

            // background
            g.setPaint(new GradientPaint(0, 0, GREEN_DARK, w, h, GREEN_MID));
            g.fillRect(0, 0, w, h);

            // soft sunrise glow, low in the corner
            double gx = w * 0.18, gy = h * 1.02, gr = Math.max(w, h) * 0.75;
            g.setPaint(new RadialGradientPaint((float) gx, (float) gy, (float) gr,
                new float[]{0f, 1f},
                new Color[]{new Color(232, 190, 104, 70), new Color(232, 190, 104, 0)}));
            g.fill(new Rectangle2D.Double(0, 0, w, h));

            // concentric rings (rising sun motif)
            g.setStroke(new BasicStroke(1.2f));
            for (int i = 1; i <= 7; i++) {
                double r = i * 120 * u;
                int alpha = Math.max(8, 38 - i * 4);
                g.setColor(new Color(255, 255, 255, alpha));
                g.draw(new Ellipse2D.Double(gx - r, gy - r, r * 2, r * 2));
            }

            // logo mark + wordmark
            double lx = 64 * u, ly = 64 * u, ls = 40 * u;
            g.setColor(GOLD);
            g.setStroke(new BasicStroke((float) (2.2 * u), BasicStroke.CAP_ROUND,
                BasicStroke.JOIN_ROUND));
            g.draw(new RoundRectangle2D.Double(lx, ly, ls, ls, 12 * u, 12 * u));
            g.fill(new Arc2D.Double(lx + ls * 0.22, ly + ls * 0.38, ls * 0.56, ls * 0.56,
                0, 180, Arc2D.CHORD));
            g.draw(new Line2D.Double(lx + ls * 0.14, ly + ls * 0.66, lx + ls * 0.86, ly + ls * 0.66));

            g.setFont(new Font("Segoe UI", Font.BOLD, (int) (24 * u)));
            g.setColor(Color.WHITE);
            g.drawString("REbirth", (float) (lx + ls + 14 * u), (float) (ly + ls * 0.70));

            // accent line + headline
            double hy = h * 0.42;
            g.setColor(GOLD);
            g.fill(new RoundRectangle2D.Double(lx, hy - 70 * u, 56 * u, 4 * u, 4 * u, 4 * u));

            g.setColor(Color.WHITE);
            g.setFont(new Font("Georgia", Font.BOLD, (int) (46 * u)));
            g.drawString("Every ending can be", (float) lx, (float) hy);
            g.drawString("a new beginning.", (float) lx, (float) (hy + 58 * u));

            g.setFont(new Font("Segoe UI", Font.PLAIN, (int) (17 * u)));
            g.setColor(new Color(255, 255, 255, 190));
            g.drawString("Rebuild, reflect and move forward,", (float) lx, (float) (hy + 110 * u));
            g.drawString("one steady step at a time.", (float) lx, (float) (hy + 138 * u));

            // footer
            g.setFont(new Font("Segoe UI", Font.PLAIN, (int) (12 * u)));
            g.setColor(new Color(255, 255, 255, 120));
            g.drawString("\u00A9 REbirth", (float) lx, (float) (h - 36 * u));

            g.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(WelcomeForm::new);
    }
}