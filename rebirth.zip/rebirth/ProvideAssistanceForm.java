package rebirth;

import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.Calendar;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * NGO: record the help given to a prisoner (food, shelter, training, legal
 * aid, money...). An entry can be linked to one of the prisoner's open
 * support requests and can move that request forward at the same time.
 *
 * Table: ASSISTANCE_RECORDS (created automatically if missing).
 * Status values: In Progress, Delivered
 * An NGO only ever sees and changes its own records.
 */
public class ProvideAssistanceForm extends JFrame {

    private static final String DAY = "dd-MMM-yyyy";

    private static final String[] TYPES = {
        "Food and Essentials", "Clothing", "Temporary Shelter", "Job Placement",
        "Skill Training", "Education Support", "Medical Aid", "Legal Aid",
        "Family Reunion Support", "Financial Aid", "Other"
    };

    private static final CounsellorUtil.Item NO_REQUEST =
        new CounsellorUtil.Item(0, "None (not linked to a request)");

    private final int userId;
    private boolean loading;

    private final JComboBox<CounsellorUtil.Item> prisonerBox = new JComboBox<>();
    private final JComboBox<CounsellorUtil.Item> requestBox = new JComboBox<>();
    private final JComboBox<String> requestAction = CounsellorUtil.combo(
        "Leave request status as it is", "Set request to In Progress",
        "Mark request Resolved");
    private final JComboBox<String> typeBox = CounsellorUtil.combo(TYPES);
    private final JTextArea details = Theme.area(3);
    private final JSpinner dateSpin;
    private final JTextField value = Theme.field();
    private final JComboBox<String> statusBox =
        CounsellorUtil.combo("In Progress", "Delivered");
    private final JLabel summary = new JLabel(" ");

    private final DefaultTableModel model;
    private final JTable table;

    public ProvideAssistanceForm(int userId, String fullName, String role) {

        this.userId = userId;

        setTitle("REbirth - Provide Assistance");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1000, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        dateSpin = CounsellorUtil.dateSpinner(new java.util.Date(), DAY);

        // last two columns (prisoner id, request id) are kept but hidden
        model = CounsellorUtil.readOnlyModel("ID", "Prisoner", "Type", "Details",
            "Date", "Value", "Status", "Request", "PID", "RID");
        table = CounsellorUtil.table(model);
        table.getColumnModel().getColumn(0).setMaxWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(170);
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(320);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        table.getColumnModel().getColumn(7).setPreferredWidth(70);
        table.removeColumn(table.getColumnModel().getColumn(9));
        table.removeColumn(table.getColumnModel().getColumn(8));

        loading = true;
        try (Connection con = DBConnection.getConnection()) {
            ensureTable(con);
            for (CounsellorUtil.Item i : CounsellorUtil.prisoners(con)) {
                prisonerBox.addItem(i);
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
        loading = false;

        prisonerBox.setFont(Theme.f(Font.PLAIN, 14));
        prisonerBox.setPreferredSize(new Dimension(320, 36));
        requestBox.setFont(Theme.f(Font.PLAIN, 14));
        requestBox.setPreferredSize(new Dimension(320, 36));
        summary.setFont(Theme.f(Font.BOLD, 13));
        summary.setForeground(Theme.GREEN_DARK);

        JPanel root = new Theme.Backdrop(new BorderLayout());
        root.add(new Theme.HeaderBand("Provide Assistance",
            "Welcome, " + fullName + "  |  Role: " + role), BorderLayout.NORTH);

        JPanel card = CounsellorUtil.formCard();
        CounsellorUtil.addRow(card, 0, "Prisoner", prisonerBox);
        CounsellorUtil.addRow(card, 1, "Linked request", requestBox);
        CounsellorUtil.addRow(card, 2, "On saving", requestAction);
        CounsellorUtil.addRow(card, 3, "Assistance type", typeBox);
        CounsellorUtil.addRow(card, 4, "Details", Theme.scroll(details));
        CounsellorUtil.addRow(card, 5, "Date", dateSpin);
        CounsellorUtil.addRow(card, 6, "Value (Rs., optional)", value);
        CounsellorUtil.addRow(card, 7, "Status", statusBox);

        JPanel top = new JPanel(new BorderLayout(0, 8));
        top.setOpaque(false);
        top.add(card, BorderLayout.NORTH);
        top.add(summary, BorderLayout.SOUTH);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        body.add(top, BorderLayout.NORTH);
        body.add(CounsellorUtil.scroll(table), BorderLayout.CENTER);
        body.add(buildButtons(), BorderLayout.SOUTH);

        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        prisonerBox.addActionListener(e -> {
            if (!loading) {
                clearForm();
            }
        });
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFromRow();
            }
        });

        reloadRequests(currentPrisonerId(), 0);
        load();
    }

    /** Creates ASSISTANCE_RECORDS the first time it is needed. */
    static void ensureTable(Connection con) {

        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                 "SELECT 1 FROM ASSISTANCE_RECORDS WHERE 1=0")) {
            return;
        } catch (SQLException missing) {
            // create below
        }
        try (Statement st = con.createStatement()) {
            st.execute("CREATE TABLE ASSISTANCE_RECORDS ("
                + "ASSISTANCE_ID NUMBER PRIMARY KEY, "
                + "PRISONER_ID NUMBER NOT NULL, "
                + "NGO_USER_ID NUMBER NOT NULL, "
                + "REQUEST_ID NUMBER, "
                + "ASSISTANCE_TYPE VARCHAR2(40), "
                + "DETAILS VARCHAR2(500 CHAR), "
                + "ASSISTANCE_DATE DATE, "
                + "VALUE_INR NUMBER(12,2), "
                + "STATUS VARCHAR2(20) DEFAULT 'In Progress', "
                + "CREATED_DATE DATE DEFAULT SYSDATE)");
        } catch (SQLException ignored) {
            // another window may have created it at the same time
        }
    }

    private JPanel buildButtons() {

        Theme.Button add = new Theme.Button("Add Record", Theme.GREEN, Color.WHITE);
        Theme.Button update = new Theme.Button("Update Selected",
            Theme.GREEN_DARK, Color.WHITE);
        Theme.Button delete = new Theme.Button("Delete Selected",
            Theme.RED, Color.WHITE);
        Theme.Button clear = new Theme.Button("Clear",
            new Color(180, 120, 145), Color.WHITE);
        Theme.Button refresh = new Theme.Button("Refresh",
            new Color(120, 130, 150), Color.WHITE);

        add.addActionListener(e -> addRecord());
        update.addActionListener(e -> updateRecord());
        delete.addActionListener(e -> deleteRecord());
        clear.addActionListener(e -> clearForm());
        refresh.addActionListener(e -> load());

        return CounsellorUtil.buttonRow(add, update, delete, clear, refresh);
    }

    // ------------------------------------------------------------------
    private int currentPrisonerId() {
        CounsellorUtil.Item p = (CounsellorUtil.Item) prisonerBox.getSelectedItem();
        return p == null ? 0 : p.id;
    }

    private static void select(JComboBox<CounsellorUtil.Item> box, int id) {
        for (int i = 0; i < box.getItemCount(); i++) {
            if (box.getItemAt(i).id == id) {
                box.setSelectedIndex(i);
                return;
            }
        }
    }

    /** Open requests of the prisoner (plus the one already linked, if any). */
    private void reloadRequests(int prisonerId, int keepId) {

        requestBox.removeAllItems();
        requestBox.addItem(NO_REQUEST);
        if (prisonerId == 0) {
            return;
        }
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "SELECT REQUEST_ID, REQUEST_TYPE, DESCRIPTION FROM SUPPORT_REQUESTS "
                 + "WHERE PRISONER_ID = ? AND (UPPER(STATUS) <> 'RESOLVED' "
                 + "OR REQUEST_ID = ?) ORDER BY REQUEST_ID")) {
            ps.setInt(1, prisonerId);
            ps.setInt(2, keepId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    requestBox.addItem(new CounsellorUtil.Item(rs.getInt(1),
                        "#" + rs.getInt(1) + "  " + rs.getString(2) + " - "
                        + Theme.shorten(Theme.nz(rs.getString(3)), 40)));
                }
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private BigDecimal parseValue() throws NumberFormatException {
        String v = value.getText().trim().replace(",", "");
        if (v.isEmpty()) {
            return null;
        }
        BigDecimal b = new BigDecimal(v);
        if (b.signum() < 0 || b.compareTo(new BigDecimal("10000000")) > 0) {
            throw new NumberFormatException();
        }
        return b;
    }

    private boolean valid() {
        if (currentPrisonerId() == 0) {
            CounsellorUtil.error(this, "Select a prisoner.");
            return false;
        }
        String d = details.getText().trim();
        if (d.isEmpty()) {
            CounsellorUtil.error(this, "Enter the details of the assistance.");
            return false;
        }
        if (d.length() > 500) {
            CounsellorUtil.error(this, "Details are too long (max 500).");
            return false;
        }
        try {
            parseValue();
        } catch (NumberFormatException ex) {
            CounsellorUtil.error(this,
                "Value must be a number between 0 and 10,000,000.");
            return false;
        }
        return true;
    }

    private static java.sql.Date toSqlDate(JSpinner s) {
        return new java.sql.Date(((java.util.Date) s.getValue()).getTime());
    }

    // ------------------------------------------------------------------
    private void load() {

        model.setRowCount(0);
        int records = 0;
        int people = 0;
        BigDecimal total = BigDecimal.ZERO;

        try (Connection con = DBConnection.getConnection()) {

            ensureTable(con);

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT a.ASSISTANCE_ID, u.FULL_NAME, a.ASSISTANCE_TYPE, "
                    + "a.DETAILS, a.ASSISTANCE_DATE, a.VALUE_INR, a.STATUS, "
                    + "a.REQUEST_ID, a.PRISONER_ID "
                    + "FROM ASSISTANCE_RECORDS a "
                    + "JOIN PRISONER_DETAILS p ON p.PRISONER_ID = a.PRISONER_ID "
                    + "JOIN USERS u ON u.USER_ID = p.USER_ID "
                    + "WHERE a.NGO_USER_ID = ? "
                    + "ORDER BY a.ASSISTANCE_DATE DESC, a.ASSISTANCE_ID DESC")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        BigDecimal v = rs.getBigDecimal(6);
                        int rid = rs.getInt(8);
                        model.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getString(3),
                            Theme.nz(rs.getString(4)),
                            CounsellorUtil.fmt(rs.getTimestamp(5), DAY),
                            v == null ? "" : "Rs. " + v.stripTrailingZeros().toPlainString(),
                            rs.getString(7), rid == 0 ? "-" : "#" + rid,
                            rs.getInt(9), rid
                        });
                    }
                }
            }

            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*), COUNT(DISTINCT PRISONER_ID), "
                    + "NVL(SUM(VALUE_INR), 0) FROM ASSISTANCE_RECORDS "
                    + "WHERE NGO_USER_ID = ?")) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    records = rs.getInt(1);
                    people = rs.getInt(2);
                    total = rs.getBigDecimal(3);
                }
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }

        summary.setText(records == 0 ? "No assistance recorded yet"
            : records + " records  |  " + people + " people helped  |  Rs. "
              + total.stripTrailingZeros().toPlainString() + " in total");
        clearForm();
    }

    private void addRecord() {

        if (!valid()) {
            return;
        }
        CounsellorUtil.Item req = (CounsellorUtil.Item) requestBox.getSelectedItem();
        int action = requestAction.getSelectedIndex();
        String text = details.getText().trim();

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                int id = CounsellorUtil.nextId(con, "ASSISTANCE_RECORDS", "ASSISTANCE_ID");

                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO ASSISTANCE_RECORDS (ASSISTANCE_ID, PRISONER_ID, "
                        + "NGO_USER_ID, REQUEST_ID, ASSISTANCE_TYPE, DETAILS, "
                        + "ASSISTANCE_DATE, VALUE_INR, STATUS) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    ps.setInt(1, id);
                    ps.setInt(2, currentPrisonerId());
                    ps.setInt(3, userId);
                    if (req == null || req.id == 0) {
                        ps.setNull(4, Types.NUMERIC);
                    } else {
                        ps.setInt(4, req.id);
                    }
                    ps.setString(5, typeBox.getSelectedItem().toString());
                    ps.setString(6, text);
                    ps.setDate(7, toSqlDate(dateSpin));
                    BigDecimal v = parseValue();
                    if (v == null) {
                        ps.setNull(8, Types.NUMERIC);
                    } else {
                        ps.setBigDecimal(8, v);
                    }
                    ps.setString(9, statusBox.getSelectedItem().toString());
                    ps.executeUpdate();
                }

                if (req != null && req.id != 0 && action == 1) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE SUPPORT_REQUESTS SET STATUS = 'In Progress' "
                            + "WHERE REQUEST_ID = ? AND PRISONER_ID = ? "
                            + "AND UPPER(STATUS) = 'PENDING'")) {
                        ps.setInt(1, req.id);
                        ps.setInt(2, currentPrisonerId());
                        ps.executeUpdate();
                    }
                } else if (req != null && req.id != 0 && action == 2) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE SUPPORT_REQUESTS SET STATUS = 'Resolved', "
                            + "RESOLUTION_DETAILS = ? "
                            + "WHERE REQUEST_ID = ? AND PRISONER_ID = ?")) {
                        ps.setString(1, text);
                        ps.setInt(2, req.id);
                        ps.setInt(3, currentPrisonerId());
                        ps.executeUpdate();
                    }
                }
                con.commit();

            } catch (SQLException | RuntimeException ex) {
                con.rollback();
                throw ex;
            }

            CounsellorUtil.info(this, "Assistance recorded.");
            load();

        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void updateRecord() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select a record from the table.");
            return;
        }
        if (!valid()) {
            return;
        }
        int id = (Integer) model.getValueAt(row, 0);

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "UPDATE ASSISTANCE_RECORDS SET ASSISTANCE_TYPE = ?, DETAILS = ?, "
                 + "ASSISTANCE_DATE = ?, VALUE_INR = ?, STATUS = ? "
                 + "WHERE ASSISTANCE_ID = ? AND NGO_USER_ID = ?")) {

            ps.setString(1, typeBox.getSelectedItem().toString());
            ps.setString(2, details.getText().trim());
            ps.setDate(3, toSqlDate(dateSpin));
            BigDecimal v = parseValue();
            if (v == null) {
                ps.setNull(4, Types.NUMERIC);
            } else {
                ps.setBigDecimal(4, v);
            }
            ps.setString(5, statusBox.getSelectedItem().toString());
            ps.setInt(6, id);
            ps.setInt(7, userId);
            ps.executeUpdate();

            CounsellorUtil.info(this, "Record updated.");
            load();

        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void deleteRecord() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select a record from the table.");
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this, "Delete this record?",
            "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }
        int id = (Integer) model.getValueAt(row, 0);

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "DELETE FROM ASSISTANCE_RECORDS "
                 + "WHERE ASSISTANCE_ID = ? AND NGO_USER_ID = ?")) {
            ps.setInt(1, id);
            ps.setInt(2, userId);
            ps.executeUpdate();
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void fillFromRow() {

        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        loading = true;
        try {
            int pid = (Integer) model.getValueAt(row, 8);
            int rid = (Integer) model.getValueAt(row, 9);
            select(prisonerBox, pid);
            reloadRequests(pid, rid);
            select(requestBox, rid);
            typeBox.setSelectedItem(model.getValueAt(row, 2));
            details.setText(String.valueOf(model.getValueAt(row, 3)));
            statusBox.setSelectedItem(model.getValueAt(row, 6));
            String v = String.valueOf(model.getValueAt(row, 5));
            value.setText(v.replace("Rs. ", ""));
            try {
                dateSpin.setValue(new java.text.SimpleDateFormat(DAY)
                    .parse(String.valueOf(model.getValueAt(row, 4))));
            } catch (java.text.ParseException ignored) {
                // keep the current date
            }
            // who and which request cannot change after saving
            prisonerBox.setEnabled(false);
            requestBox.setEnabled(false);
            requestAction.setEnabled(false);
        } finally {
            loading = false;
        }
    }

    private void clearForm() {

        boolean wasLoading = loading;
        loading = true;
        try {
            table.clearSelection();
            prisonerBox.setEnabled(true);
            requestBox.setEnabled(true);
            requestAction.setEnabled(true);
            reloadRequests(currentPrisonerId(), 0);
            requestAction.setSelectedIndex(0);
            typeBox.setSelectedIndex(0);
            details.setText("");
            value.setText("");
            statusBox.setSelectedIndex(0);
            dateSpin.setValue(Calendar.getInstance().getTime());
        } finally {
            loading = wasLoading;
        }
    }
}