package rebirth;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/**
 * Government Command Centre (Administrator).
 *
 * Shows ANONYMISED totals only: no names, no individual records.
 * Districts with fewer people than CompassEngine.MIN_GROUP are hidden
 * unless "demo mode" is ticked.
 *
 * Every number is calculated from the Oracle tables by CompassEngine.
 */
public class CommandCentreForm extends JFrame {

    private final boolean admin;

    private final CompassVisuals.KpiCard kPeople =
        new CompassVisuals.KpiCard("People tracked", CompassVisuals.D_NEON);
    private final CompassVisuals.KpiCard kAvg =
        new CompassVisuals.KpiCard("Average readiness", new Color(120, 200, 255));
    private final CompassVisuals.KpiCard kFlag =
        new CompassVisuals.KpiCard("Flagged people", new Color(255, 110, 110));
    private final CompassVisuals.KpiCard kWait =
        new CompassVisuals.KpiCard("Requests > 7 days", new Color(255, 180, 80));
    private final CompassVisuals.KpiCard kGap =
        new CompassVisuals.KpiCard("Gaps with no scheme", new Color(200, 150, 255));

    private final CompassVisuals.HeatGrid grid = new CompassVisuals.HeatGrid();
    private final CompassVisuals.TnMap map = new CompassVisuals.TnMap();
    private final CardLayout mapCards = new CardLayout();
    private final JPanel mapHolder = new JPanel(mapCards);
    private final JLabel[] legend = new JLabel[3];
    private final CompassVisuals.PillarBars bars = new CompassVisuals.PillarBars();
    private final CompassVisuals.BandDonut donut = new CompassVisuals.BandDonut();
    private final JLabel barsTitle = new JLabel();
    private final JLabel barsSub = new JLabel();
    private final JPanel actions = new JPanel();
    private final JLabel status = new JLabel(" ");
    private final JCheckBox demoMode = new JCheckBox("Demo mode: show small districts");

    private CompassEngine.Stats stats;
    private Timer reveal;

    public CommandCentreForm(int userId, String fullName, String role) {

        admin = role.equalsIgnoreCase("Administrator") || role.equalsIgnoreCase("Admin");

        setTitle("REbirth - Command Centre");
        FrameFit.maximize(this);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(CompassVisuals.D_BG1);
        root.add(new Theme.HeaderBand("Command Centre",
            "Anonymised totals only  |  " + fullName + "  |  Role: " + role),
            BorderLayout.NORTH);

        if (!admin) {
            JLabel l = new JLabel("The Command Centre is for administrators only.",
                SwingConstants.CENTER);
            l.setFont(Theme.f(Font.BOLD, 16));
            l.setForeground(CompassVisuals.D_TEXT);
            root.add(l, BorderLayout.CENTER);
            setContentPane(root);
            return;
        }

        JPanel bg = new JPanel(new BorderLayout(0, 14)) {
            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setPaint(new GradientPaint(0, 0, CompassVisuals.D_BG1,
                    0, getHeight(), CompassVisuals.D_BG2));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.dispose();
            }
        };
        bg.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));

        bg.add(buildToolbar(), BorderLayout.NORTH);
        bg.add(buildMain(), BorderLayout.CENTER);
        bg.add(buildFooter(), BorderLayout.SOUTH);

        JScrollPane sp = new JScrollPane(bg);
        sp.setBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(22);
        root.add(sp, BorderLayout.CENTER);
        setContentPane(root);

        grid.setOnSelect(this::districtPicked);
        map.setOnSelect(this::districtPicked);
        load();
    }

    // ------------------------------------------------------------------
    private JPanel buildToolbar() {

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setOpaque(false);

        Theme.Button refresh = new Theme.Button("Refresh", new Color(60, 110, 98), Color.WHITE);
        Theme.Button centres = new Theme.Button("Manage centres",
            new Color(52, 120, 204), Color.WHITE);
        centres.addActionListener(e ->
            new CentresForm("Administrator", "Administrator", this::load).setVisible(true));
        refresh.addActionListener(e -> load());

        demoMode.setOpaque(false);
        demoMode.setForeground(CompassVisuals.D_TEXT);
        demoMode.setFont(Theme.f(Font.BOLD, 12));
        demoMode.addActionListener(e -> load());

        status.setFont(Theme.f(Font.PLAIN, 12));
        status.setForeground(CompassVisuals.D_MUTED);

        bar.add(refresh);
        bar.add(centres);
        bar.add(demoMode);
        bar.add(status);
        return bar;
    }

    private JPanel buildMain() {

        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.BOTH;

        // KPI row
        JPanel k = new JPanel(new GridLayout(1, 5, 14, 0));
        k.setOpaque(false);
        k.setPreferredSize(new Dimension(100, 114));
        k.add(kPeople);
        k.add(kAvg);
        k.add(kFlag);
        k.add(kWait);
        k.add(kGap);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2; g.weightx = 1; g.weighty = 0;
        g.insets = new Insets(0, 0, 16, 0);
        p.add(k, g);

        // district map (Tamil Nadu) / grid
        DarkCard mapCard = new DarkCard();
        mapCard.setLayout(new BorderLayout(14, 8));
        mapCard.add(head("Tamil Nadu overview",
            "Click a district to see its pillars. Hover for details."),
            BorderLayout.NORTH);

        mapHolder.setOpaque(false);
        mapHolder.add(map, "map");
        mapHolder.add(grid, "grid");
        mapCard.add(mapHolder, BorderLayout.CENTER);

        JPanel side = new JPanel();
        side.setOpaque(false);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(230, 100));

        ButtonGroup bg = new ButtonGroup();
        String[] names = {"Map: readiness", "Map: centres and NGOs", "Grid view"};
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            JToggleButton b = new JToggleButton(names[i]);
            b.setFont(Theme.f(Font.BOLD, 12));
            b.setFocusPainted(false);
            b.setForeground(CompassVisuals.D_TEXT);
            b.setBackground(CompassVisuals.D_CARD);
            b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CompassVisuals.D_LINE),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> {
                if (mode == 2) {
                    mapCards.show(mapHolder, "grid");
                    grid.replay();
                } else {
                    mapCards.show(mapHolder, "map");
                    map.setLayer(mode);
                }
            });
            if (i == 0) {
                b.setSelected(true);
            }
            bg.add(b);
            side.add(b);
            side.add(Box.createVerticalStrut(6));
        }
        side.add(Box.createVerticalStrut(14));
        JLabel kt = new JLabel("CENTRES AND PARTNERS");
        kt.setFont(Theme.f(Font.BOLD, 11));
        kt.setForeground(CompassVisuals.D_MUTED);
        kt.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(kt);
        side.add(Box.createVerticalStrut(8));
        for (int i = 0; i < 3; i++) {
            legend[i] = new JLabel(" ");
            legend[i].setFont(Theme.f(Font.BOLD, 13));
            legend[i].setForeground(CompassVisuals.D_TEXT);
            legend[i].setIcon(dotIcon(CompassVisuals.TnMap.TYPE_COLORS[i]));
            legend[i].setIconTextGap(10);
            legend[i].setAlignmentX(Component.LEFT_ALIGNMENT);
            side.add(legend[i]);
            side.add(Box.createVerticalStrut(8));
        }
        mapCard.add(side, BorderLayout.EAST);
        mapCard.setPreferredSize(new Dimension(100, 600));

        g.gridy = 1; g.gridwidth = 1; g.weightx = 0.58; g.weighty = 0.6;
        g.insets = new Insets(0, 0, 16, 16);
        p.add(mapCard, g);

        // pillar bars
        DarkCard barCard = new DarkCard();
        barCard.setLayout(new BorderLayout(0, 8));
        barsTitle.setFont(Theme.f(Font.BOLD, 17));
        barsTitle.setForeground(CompassVisuals.D_TEXT);
        barsSub.setFont(Theme.f(Font.PLAIN, 12));
        barsSub.setForeground(CompassVisuals.D_MUTED);
        JPanel bh = new JPanel();
        bh.setOpaque(false);
        bh.setLayout(new BoxLayout(bh, BoxLayout.Y_AXIS));
        barsTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        barsSub.setAlignmentX(Component.LEFT_ALIGNMENT);
        bh.add(barsTitle);
        bh.add(barsSub);
        barCard.add(bh, BorderLayout.NORTH);
        barCard.add(bars, BorderLayout.CENTER);
        g.gridx = 1; g.weightx = 0.42; g.insets = new Insets(0, 0, 16, 0);
        p.add(barCard, g);

        // actions
        DarkCard actCard = new DarkCard();
        actCard.setLayout(new BorderLayout(0, 8));
        actCard.add(head("What to do next",
            "Plain-language actions, calculated from your own data"), BorderLayout.NORTH);
        actions.setOpaque(false);
        actions.setLayout(new BoxLayout(actions, BoxLayout.Y_AXIS));
        actCard.add(actions, BorderLayout.CENTER);
        g.gridx = 0; g.gridy = 2; g.weightx = 0.58; g.weighty = 0.4;
        g.insets = new Insets(0, 0, 0, 16);
        p.add(actCard, g);

        // donut
        DarkCard donutCard = new DarkCard();
        donutCard.setLayout(new BorderLayout(0, 8));
        donutCard.add(head("Readiness bands", "How many people sit in each band"),
            BorderLayout.NORTH);
        donutCard.add(donut, BorderLayout.CENTER);
        g.gridx = 1; g.weightx = 0.42; g.insets = new Insets(0, 0, 0, 0);
        p.add(donutCard, g);

        return p;
    }

    private JPanel buildFooter() {
        JLabel l = new JLabel("<html><body style='width:1200px'>"
            + "<b>Privacy:</b> this view shows totals only; names and individual records stay "
            + "with the counsellor. Districts with fewer than " + CompassEngine.MIN_GROUP
            + " people are hidden.  <b>Honest limits:</b> the index is a decision-support "
            + "tool, not a prediction of who will reoffend, and its weights are a starting "
            + "point that experts would adjust.</body></html>");
        l.setFont(Theme.f(Font.PLAIN, 11));
        l.setForeground(CompassVisuals.D_MUTED);
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(l, BorderLayout.CENTER);
        return p;
    }

    private static JPanel head(String t, String s) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel a = new JLabel(t);
        a.setFont(Theme.f(Font.BOLD, 17));
        a.setForeground(CompassVisuals.D_TEXT);
        a.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel b = new JLabel(s);
        b.setFont(Theme.f(Font.PLAIN, 12));
        b.setForeground(CompassVisuals.D_MUTED);
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(a);
        p.add(b);
        return p;
    }

    // ------------------------------------------------------------------
    private void load() {

        status.setText("Calculating from the database...");
        int min = demoMode.isSelected() ? 1 : CompassEngine.MIN_GROUP;

        new SwingWorker<CompassEngine.Stats, Void>() {
            @Override
            protected CompassEngine.Stats doInBackground() throws Exception {
                try (Connection con = DBConnection.getConnection()) {
                    CounsellorUtil.ensureTables(con);
                    return CompassEngine.stats(con, min);
                }
            }

            @Override
            protected void done() {
                try {
                    apply(get());
                    status.setText(" ");
                } catch (Exception ex) {
                    status.setText(" ");
                    CounsellorUtil.error(CommandCentreForm.this,
                        String.valueOf(ex.getCause() != null
                            ? ex.getCause().getMessage() : ex.getMessage()));
                }
            }
        }.execute();
    }

    private void apply(CompassEngine.Stats s) {

        stats = s;
        int n = s.people.size();

        kPeople.setValue(n, "", s.unassigned + " without a district");
        kAvg.setValue(s.avg, "/100", n == 0 ? "no data"
            : CompassEngine.BANDS[CompassEngine.band(s.avg)]);
        kFlag.setValue(s.high + s.medium, "", s.high + " need a call today");
        kWait.setValue(s.pendingOver7, "", "waiting more than a week");
        kGap.setValue(CompassEngine.uncoveredGaps(s), "", "weak pillars, no scheme");

        grid.setData(s.districts);
        int nd = s.districts.size();
        double[] av = new double[nd];
        int[] pp = new int[nd];
        boolean[] hd = new boolean[nd];
        for (int i = 0; i < nd; i++) {
            av[i] = s.districts.get(i).avg;
            pp[i] = s.districts.get(i).n;
            hd[i] = s.districts.get(i).hidden;
        }
        map.setReadiness(av, pp, hd);
        map.setFacilities(s.centres.byDistrict);
        for (int i = 0; i < 3; i++) {
            legend[i].setText(s.centres.totals[i] + "  " + CompassEngine.CENTRE_TYPES[i]
                + (s.centres.totals[i] == 1 ? "" : "s"));
        }
        showBars(-1);
        donut.setData(s.bands);
        showActions(s.actions);
    }

    private void showBars(int districtIndex) {

        if (stats == null) {
            return;
        }
        if (districtIndex >= 0 && districtIndex < stats.districts.size()) {
            CompassEngine.District d = stats.districts.get(districtIndex);
            if (d.n > 0 && !d.hidden) {
                barsTitle.setText("Pillar averages  \u00B7  " + d.name);
                barsSub.setText(d.n + " people. Click the tile again for statewide.");
                bars.setData(d.pillarAvg, CompassEngine.weakestOf(d.pillarAvg));
                return;
            }
        }
        barsTitle.setText("Where the gaps are  \u00B7  whole state");
        boolean any = !stats.people.isEmpty();
        barsSub.setText(any ? "Average score of every pillar. The weakest one glows."
            : "No data yet.");
        bars.setData(stats.pillarAvg, stats.weakest);
    }

    private void districtPicked(int index) {
        showBars(index);
    }

    private void showActions(List<String> lines) {

        if (reveal != null) {
            reveal.stop();
        }
        actions.removeAll();
        List<JComponent> rows = new ArrayList<>();
        for (String s : lines) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            row.setBorder(BorderFactory.createEmptyBorder(6, 0, 6, 0));
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.add(new Dot(), BorderLayout.WEST);
            JLabel l = new JLabel("<html><body style='width:560px'>" + Theme.esc(s)
                + "</body></html>");
            l.setFont(Theme.f(Font.PLAIN, 14));
            l.setForeground(CompassVisuals.D_TEXT);
            row.add(l, BorderLayout.CENTER);
            row.setVisible(false);
            actions.add(row);
            rows.add(row);
        }
        actions.revalidate();
        actions.repaint();

        int[] i = {0};
        reveal = new Timer(260, e -> {
            if (i[0] < rows.size()) {
                rows.get(i[0]++).setVisible(true);
                actions.revalidate();
                actions.repaint();
            } else {
                ((Timer) e.getSource()).stop();
            }
        });
        reveal.setInitialDelay(500);
        reveal.start();
    }

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    private static Icon dotIcon(Color c) {
        return new Icon() {
            public int getIconWidth() {
                return 14;
            }

            public int getIconHeight() {
                return 14;
            }

            public void paintIcon(Component comp, Graphics g0, int x, int y) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.quality(g);
                g.setColor(c);
                g.fill(new Ellipse2D.Double(x, y, 14, 14));
                g.dispose();
            }
        };
    }

    /** Dark rounded card. */
    private static class DarkCard extends JPanel {

        DarkCard() {
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, getWidth() - 1,
                getHeight() - 1, 22, 22);
            g.setPaint(new GradientPaint(0, 0, CompassVisuals.D_CARD,
                0, getHeight(), CompassVisuals.D_BG2));
            g.fill(r);
            g.setColor(CompassVisuals.D_LINE);
            g.draw(r);
            g.dispose();
            super.paintComponent(g0);
        }
    }

    /** Pulsing neon bullet. */
    private static class Dot extends CompassVisuals.AnimPanel {

        Dot() {
            continuous = true;
            setPreferredSize(new Dimension(22, 22));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.quality(g);
            double p = 0.5 + 0.5 * Math.sin(clock * 3);
            double r = 8 + 2 * p;
            g.setColor(CompassVisuals.alpha(CompassVisuals.D_NEON, (int) (60 - 30 * p)));
            g.fill(new Ellipse2D.Double(11 - r, 12 - r, r * 2, r * 2));
            g.setColor(CompassVisuals.D_NEON);
            g.fill(new Ellipse2D.Double(8, 9, 6, 6));
            g.dispose();
        }
    }
}