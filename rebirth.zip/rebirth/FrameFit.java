package rebirth;

import java.awt.*;
import javax.swing.*;

/** Sizes a frame to fit the screen and lets the content scroll if the window is small. */
public final class FrameFit {

    private FrameFit() { }

    /** Preferred size, but never bigger than 96% of the usable screen; centred. */
    public static void apply(JFrame f, int prefW, int prefH) {
        Rectangle b = GraphicsEnvironment.getLocalGraphicsEnvironment()
            .getMaximumWindowBounds();
        int w = Math.min(prefW, (int) (b.width * 0.96));
        int h = Math.min(prefH, (int) (b.height * 0.96));
        f.setMinimumSize(new Dimension(Math.min(800, w), Math.min(560, h)));
        f.setSize(w, h);
        f.setLocation(b.x + (b.width - w) / 2, b.y + (b.height - h) / 2);
    }

    /** Fill the screen (respects the taskbar). */
    public static void maximize(JFrame f) {
        apply(f, 1100, 720);
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    /** Wrap a body panel so it stretches when there is room and scrolls when there is not. */
    public static JScrollPane scrollable(JComponent body) {
        JScrollPane sp = new JScrollPane(new Page(body),
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(22);
        return sp;
    }

    private static class Page extends JPanel implements Scrollable {
        Page(JComponent c) {
            super(new BorderLayout());
            setOpaque(false);
            add(c, BorderLayout.CENTER);
        }
        public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 20; }
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) {
            return o == SwingConstants.VERTICAL ? r.height - 40 : r.width - 40;
        }
        public boolean getScrollableTracksViewportWidth() { return true; }
        public boolean getScrollableTracksViewportHeight() {
            return getParent() instanceof JViewport
                && getParent().getHeight() > getPreferredSize().height;
        }
    }
}