package rebirth;

import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/**
 * Small helpers shared by ManageUsersForm and ManageNgosForm.
 *
 * The name of the role column in USERS is found automatically
 * (ROLE, USER_ROLE, ROLE_NAME or USER_TYPE), so nothing here depends on
 * how your table was named.
 */
final class AdminUtil {

    private AdminUtil() { }

    private static final String[] ROLE_COLUMNS =
        {"ROLE", "USER_ROLE", "ROLE_NAME", "USER_TYPE"};

    // ---------------------------------------------------------------
    // Database
    // ---------------------------------------------------------------
    static String roleColumn(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM USERS WHERE 1=0")) {
            ResultSetMetaData md = rs.getMetaData();
            for (String want : ROLE_COLUMNS) {
                for (int i = 1; i <= md.getColumnCount(); i++) {
                    if (md.getColumnName(i).equalsIgnoreCase(want)) {
                        return md.getColumnName(i);
                    }
                }
            }
        }
        throw new SQLException("Could not find the role column in the USERS table.");
    }

    /** Role values that really exist in USERS (column name comes from the database). */
    static List<String> roles(Connection con, String col) throws SQLException {
        List<String> list = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT DISTINCT " + col
                 + " FROM USERS WHERE " + col + " IS NOT NULL ORDER BY 1")) {
            while (rs.next()) {
                list.add(rs.getString(1));
            }
        }
        return list;
    }

    static boolean isAdmin(String r) {
        return r != null && (r.equalsIgnoreCase("Admin")
            || r.equalsIgnoreCase("Administrator"));
    }

    static boolean isNgo(String r) {
        return r != null && r.equalsIgnoreCase("NGO");
    }

    /** The spelling already used in the database, or the default. */
    static String roleSpelling(List<String> roles, boolean admin) {
        for (String r : roles) {
            if (admin ? isAdmin(r) : isNgo(r)) {
                return r;
            }
        }
        return admin ? "Administrator" : "NGO";
    }

    static boolean usernameTaken(Connection con, String username) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COUNT(*) FROM USERS WHERE UPPER(USERNAME) = UPPER(?)")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    static int countAdmins(Connection con, String roleCol) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM USERS WHERE UPPER("
                 + roleCol + ") IN ('ADMIN', 'ADMINISTRATOR')")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    static void insertUser(Connection con, String roleCol, String name,
            String username, String password, String email, String phone,
            String role) throws SQLException {

        int id = CounsellorUtil.nextId(con, "USERS", "USER_ID");
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO USERS (USER_ID, FULL_NAME, USERNAME, PASSWORD, "
                + "EMAIL, PHONE, " + roleCol + ") VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, username);
            ps.setString(4, PasswordUtil.hashPassword(password));
            ps.setString(5, email);
            ps.setString(6, phone);
            ps.setString(7, role);
            ps.executeUpdate();
        }
    }

    static void updateContact(Connection con, int id, String name,
            String email, String phone) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE USERS SET FULL_NAME = ?, EMAIL = ?, PHONE = ? "
                + "WHERE USER_ID = ?")) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    static void resetPassword(Connection con, int id, String password)
            throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE USERS SET PASSWORD = ? WHERE USER_ID = ?")) {
            ps.setString(1, PasswordUtil.hashPassword(password));
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    static void deleteUser(Connection con, int id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "DELETE FROM USERS WHERE USER_ID = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 2292) {   // child records exist
                throw new SQLException("This account has linked records "
                    + "(opportunities, assistance, requests...), so it cannot "
                    + "be removed.");
            }
            throw ex;
        }
    }

    // ---------------------------------------------------------------
    // Validation (returns a message, or null when everything is fine)
    // ---------------------------------------------------------------
    static String checkContact(String name, String email, String phone) {
        if (name.length() < 2 || name.length() > 100) {
            return "Enter a name (2 to 100 characters).";
        }
        if (!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || email.length() > 100) {
            return "Enter a valid email address.";
        }
        if (!phone.isEmpty() && !phone.matches("[0-9+ -]{7,15}")) {
            return "Phone number must be 7 to 15 digits.";
        }
        return null;
    }

    static String checkUsername(String username) {
        if (!username.matches("[A-Za-z0-9_.]{3,30}")) {
            return "Username must be 3 to 30 letters, digits, dot or underscore.";
        }
        return null;
    }

    static String checkPassword(String pwd) {
        if (pwd.length() < 6 || pwd.length() > 50) {
            return "Password must be 6 to 50 characters.";
        }
        return null;
    }

    // ---------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------
    static JPasswordField passwordField() {
        JPasswordField p = new JPasswordField();
        p.setFont(Theme.f(Font.PLAIN, 14));
        p.setPreferredSize(new Dimension(200, 36));
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.INPUT_BORDER, 1),
            BorderFactory.createEmptyBorder(0, 8, 0, 8)));
        return p;
    }

    static JPanel searchRow(JTextField search, JComboBox<String> filter,
            Theme.Button go) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        row.setOpaque(false);
        JLabel l = new JLabel("Search:");
        l.setFont(Theme.f(Font.BOLD, 13));
        search.setPreferredSize(new Dimension(260, 36));
        row.add(l);
        row.add(search);
        if (filter != null) {
            JLabel f = new JLabel("Role:");
            f.setFont(Theme.f(Font.BOLD, 13));
            row.add(f);
            row.add(filter);
        }
        row.add(go);
        return row;
    }
}