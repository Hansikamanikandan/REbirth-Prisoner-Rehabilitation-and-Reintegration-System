package rebirth;

import javax.swing.JLabel;
import javax.swing.Timer;

/**
 * Makes a number label count up instead of jumping.
 *
 * Only plain whole numbers are animated. Anything else ("3 / 5", "Sapling",
 * "-") is shown straight away. A label that already shows the right value is
 * left alone, so a dashboard refresh (for example when the window regains
 * focus) never replays the animation.
 */
final class CountUp {

    private static final String TIMER_KEY = "countUpTimer";
    private static final String TARGET_KEY = "countUpTarget";
    private static final int DURATION_MS = 700;
    private static final int TICK_MS = 25;

    private CountUp() { }

    static void set(JLabel label, String text) {

        // stop an animation that is still running for an older value
        Object old = label.getClientProperty(TIMER_KEY);
        if (old instanceof Timer) {
            ((Timer) old).stop();
        }
        label.putClientProperty(TIMER_KEY, null);

        // same value as before: nothing to do
        if (text.equals(label.getText()) && label.getClientProperty(TARGET_KEY) == null) {
            return;
        }

        Integer to = parse(text);
        if (to == null || to == 0) {
            label.putClientProperty(TARGET_KEY, null);
            label.setText(text);
            return;
        }

        // start from what is shown now, or from 0 on the first load
        Integer shown = parse(label.getText());
        final int from = shown == null ? 0 : shown;
        if (from == to) {
            label.putClientProperty(TARGET_KEY, null);
            label.setText(text);
            return;
        }

        label.putClientProperty(TARGET_KEY, to);
        final long start = System.currentTimeMillis();
        Timer timer = new Timer(TICK_MS, null);
        timer.addActionListener(e -> {
            double p = Math.min(1.0, (System.currentTimeMillis() - start)
                / (double) DURATION_MS);
            double eased = 1 - Math.pow(1 - p, 3);          // ease-out
            if (p >= 1.0) {
                label.setText(text);
                label.putClientProperty(TARGET_KEY, null);
                label.putClientProperty(TIMER_KEY, null);
                timer.stop();
            } else {
                label.setText(String.valueOf(
                    (int) Math.round(from + (to - from) * eased)));
            }
        });
        label.putClientProperty(TIMER_KEY, timer);
        timer.start();
    }

    /** "12" -> 12, anything else -> null. */
    private static Integer parse(String s) {
        if (s == null || !s.matches("\\d{1,9}")) {
            return null;
        }
        return Integer.valueOf(s);
    }
}