package rebirth;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Administrator: generate summary reports from the REbirth database.
 * Pick a report, press Generate, read it in the table and, if needed,
 * export it as a CSV file (opens in Excel).
 *
 * Reports:
 *   Users by Role, Support Requests by Status / Type,
 *   Counselling Sessions by Status, Opportunities by Type,
 *   Rehabilitation Goals by Status, NGO Assistance Summary,
 *   Assistance by Type.
 */
public class GenerateReportsForm extends JFrame {

    private static final String[] REPORTS = {
        "Users by Role",
        "Support Requests by Status",
        "Support Requests by Type",
        "Counselling Sessions by Status",
        "Opportunities by Type",
        "Rehabilitation Goals by Status",
        "NGO Assistance Summary",
        "Assistance by Type"
    };

    private String roleCol = "ROLE";

    private final JComboBox<String> reportBox = CounsellorUtil.combo(REPORTS);
    private final JLabel title = new JLabel("Select a report and press Generate");
    private final JLabel summary = new JLabel(" ");

    private final DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = CounsellorUtil.table(model);

    public GenerateReportsForm(int userId, String fullName, String role) {

        setTitle("REbirth - Generate Reports");
        FrameFit.maximize(this);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        try (Connection con = DBConnection.getConnection()) {
            roleCol = AdminUtil.roleColumn(con);
            ProvideAssistanceForm.ensureTable(con);
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }

        JPanel root = new Theme.Backdrop(new BorderLayout());
        root.add(new Theme.HeaderBand("Generate Reports",
            "Welcome, " + fullName + "  |  Role: " + role), BorderLayout.NORTH);

        // ---- report picker ----
        JLabel pick = new JLabel("Report:");
        pick.setFont(Theme.f(Font.BOLD, 13));
        reportBox.setPreferredSize(new Dimension(320, 36));

        Theme.Button generate = new Theme.Button("Generate",
            Theme.GREEN, Color.WHITE);
        Theme.Button export = new Theme.Button("Export CSV",
            Theme.GREEN_DARK, Color.WHITE);
        Theme.Button print = new Theme.Button("Print",
            new Color(43, 108, 176), Color.WHITE);
        generate.addActionListener(e -> generate());
        export.addActionListener(e -> exportCsv());
        print.addActionListener(e -> printTable());
        reportBox.addActionListener(e -> generate());

        JPanel picker = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        picker.setOpaque(false);
        picker.add(pick);
        picker.add(reportBox);
        picker.add(generate);
        picker.add(export);
        picker.add(print);

        title.setFont(Theme.f(Font.BOLD, 18));
        title.setForeground(Theme.GREEN_DARK);
        summary.setFont(Theme.f(Font.BOLD, 13));
        summary.setForeground(Theme.MUTED);

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.setOpaque(false);
        top.add(picker, BorderLayout.NORTH);
        top.add(title, BorderLayout.CENTER);

        JPanel body = new JPanel(new BorderLayout(0, 12));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        body.add(top, BorderLayout.NORTH);
        body.add(CounsellorUtil.scroll(table), BorderLayout.CENTER);
        body.add(summary, BorderLayout.SOUTH);

        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        generate();
    }

    // ------------------------------------------------------------------
    /** The SQL for each report (same order as REPORTS). */
    private String sql(int index) {
        switch (index) {
            case 0:
                return "SELECT " + roleCol + " AS \"Role\", COUNT(*) AS \"Accounts\" "
                    + "FROM USERS GROUP BY " + roleCol + " ORDER BY 2 DESC";
            case 1:
                return "SELECT NVL(STATUS, 'Unknown') AS \"Status\", "
                    + "COUNT(*) AS \"Requests\" FROM SUPPORT_REQUESTS "
                    + "GROUP BY NVL(STATUS, 'Unknown') ORDER BY 2 DESC";
            case 2:
                return "SELECT NVL(REQUEST_TYPE, 'Unknown') AS \"Request Type\", "
                    + "COUNT(*) AS \"Total\", "
                    + "SUM(CASE WHEN UPPER(STATUS) = 'PENDING' THEN 1 ELSE 0 END) "
                    + "AS \"Pending\", "
                    + "SUM(CASE WHEN UPPER(STATUS) = 'IN PROGRESS' THEN 1 ELSE 0 END) "
                    + "AS \"In Progress\", "
                    + "SUM(CASE WHEN UPPER(STATUS) = 'RESOLVED' THEN 1 ELSE 0 END) "
                    + "AS \"Resolved\" "
                    + "FROM SUPPORT_REQUESTS GROUP BY NVL(REQUEST_TYPE, 'Unknown') "
                    + "ORDER BY 2 DESC";
            case 3:
                return "SELECT NVL(STATUS, 'Unknown') AS \"Status\", "
                    + "COUNT(*) AS \"Sessions\", "
                    + "COUNT(DISTINCT PRISONER_ID) AS \"Prisoners\" "
                    + "FROM COUNSELLING_SESSIONS "
                    + "GROUP BY NVL(STATUS, 'Unknown') ORDER BY 2 DESC";
            case 4:
                return "SELECT NVL(OPPORTUNITY_TYPE, 'Unknown') AS \"Type\", "
                    + "COUNT(*) AS \"Total\", "
                    + "SUM(CASE WHEN UPPER(STATUS) = 'ACTIVE' THEN 1 ELSE 0 END) "
                    + "AS \"Active\" "
                    + "FROM OPPORTUNITIES GROUP BY NVL(OPPORTUNITY_TYPE, 'Unknown') "
                    + "ORDER BY 2 DESC";
            case 5:
                return "SELECT NVL(STATUS, 'Unknown') AS \"Status\", "
                    + "COUNT(*) AS \"Goals\", "
                    + "COUNT(DISTINCT PRISONER_ID) AS \"Prisoners\" "
                    + "FROM REHABILITATION_PLANS "
                    + "GROUP BY NVL(STATUS, 'Unknown') ORDER BY 2 DESC";
            case 6:
                return "SELECT u.FULL_NAME AS \"NGO\", "
                    + "COUNT(a.ASSISTANCE_ID) AS \"Assistance Records\", "
                    + "COUNT(DISTINCT a.PRISONER_ID) AS \"People Helped\", "
                    + "NVL(SUM(a.VALUE_INR), 0) AS \"Total Value (Rs.)\" "
                    + "FROM USERS u LEFT JOIN ASSISTANCE_RECORDS a "
                    + "ON a.NGO_USER_ID = u.USER_ID "
                    + "WHERE UPPER(u." + roleCol + ") = 'NGO' "
                    + "GROUP BY u.USER_ID, u.FULL_NAME ORDER BY 2 DESC, 1";
            default:
                return "SELECT NVL(ASSISTANCE_TYPE, 'Unknown') AS \"Assistance Type\", "
                    + "COUNT(*) AS \"Records\", "
                    + "COUNT(DISTINCT PRISONER_ID) AS \"People Helped\", "
                    + "NVL(SUM(VALUE_INR), 0) AS \"Total Value (Rs.)\" "
                    + "FROM ASSISTANCE_RECORDS "
                    + "GROUP BY NVL(ASSISTANCE_TYPE, 'Unknown') ORDER BY 2 DESC";
        }
    }

    private void generate() {

        int index = reportBox.getSelectedIndex();
        if (index < 0) {
            return;
        }

        List<String> headers = new ArrayList<>();
        List<Object[]> rows = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql(index))) {

            ResultSetMetaData md = rs.getMetaData();
            int cols = md.getColumnCount();
            for (int i = 1; i <= cols; i++) {
                headers.add(md.getColumnLabel(i));
            }
            while (rs.next()) {
                Object[] row = new Object[cols];
                for (int i = 1; i <= cols; i++) {
                    Object v = rs.getObject(i);
                    if (v == null) {
                        row[i - 1] = "";
                    } else if (v instanceof BigDecimal) {
                        row[i - 1] = ((BigDecimal) v).stripTrailingZeros()
                            .toPlainString();
                    } else {
                        row[i - 1] = v.toString();
                    }
                }
                rows.add(row);
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, "Could not generate this report:\n"
                + ex.getMessage());
        }

        model.setColumnIdentifiers(headers.toArray());
        model.setRowCount(0);
        for (Object[] r : rows) {
            model.addRow(r);
        }

        title.setText(REPORTS[index]);
        summary.setText(rows.size() + " row(s)  |  Generated "
            + new SimpleDateFormat("dd-MMM-yyyy hh:mm a").format(new Date()));
    }

    // ------------------------------------------------------------------
    private void exportCsv() {

        if (model.getColumnCount() == 0) {
            CounsellorUtil.error(this, "Generate a report first.");
            return;
        }
        JFileChooser fc = new JFileChooser();
        String base = REPORTS[reportBox.getSelectedIndex()]
            .replaceAll("[^A-Za-z0-9]+", "_");
        fc.setSelectedFile(new File(base + ".csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = fc.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }

        try (PrintWriter out = new PrintWriter(file, StandardCharsets.UTF_8.name())) {
            out.print('\uFEFF');   // so Excel reads it as UTF-8
            out.println(REPORTS[reportBox.getSelectedIndex()]);
            StringBuilder line = new StringBuilder();
            for (int c = 0; c < model.getColumnCount(); c++) {
                if (c > 0) {
                    line.append(',');
                }
                line.append(csv(model.getColumnName(c)));
            }
            out.println(line);
            for (int r = 0; r < model.getRowCount(); r++) {
                line.setLength(0);
                for (int c = 0; c < model.getColumnCount(); c++) {
                    if (c > 0) {
                        line.append(',');
                    }
                    line.append(csv(String.valueOf(model.getValueAt(r, c))));
                }
                out.println(line);
            }
            CounsellorUtil.info(this, "Report saved to:\n" + file.getAbsolutePath());
        } catch (IOException ex) {
            CounsellorUtil.error(this, "Could not save the file: " + ex.getMessage());
        }
    }

    private static String csv(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private void printTable() {
        try {
            table.print(JTable.PrintMode.FIT_WIDTH,
                new java.text.MessageFormat(REPORTS[reportBox.getSelectedIndex()]),
                new java.text.MessageFormat("Page {0}"));
        } catch (java.awt.print.PrinterException ex) {
            CounsellorUtil.error(this, "Could not print: " + ex.getMessage());
        }
    }
}