package rebirth;

import java.awt.*;
import java.sql.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Administrator: see every registered account, search and filter by role,
 * correct contact details, reset a password, add an Administrator or NGO
 * account, or remove an Administrator / NGO account.
 *
 * Prisoners and counsellors register themselves (they need their own detail
 * rows), so they can be viewed and edited here but not created or deleted.
 */
public class ManageUsersForm extends JFrame {

    private final int userId;
    private String roleCol = "ROLE";
    private boolean loading;

    private final JTextField search = Theme.field();
    private final JComboBox<String> roleFilter = CounsellorUtil.combo("All");

    private final JTextField name = Theme.field();
    private final JTextField username = Theme.field();
    private final JTextField email = Theme.field();
    private final JTextField phone = Theme.field();
    private final JComboBox<String> roleBox =
        CounsellorUtil.combo("Administrator", "NGO");
    private final JPasswordField password = AdminUtil.passwordField();
    private final JLabel summary = new JLabel(" ");

    private final DefaultTableModel model = CounsellorUtil.readOnlyModel(
        "ID", "Full Name", "Username", "Email", "Phone", "Role");
    private final JTable table = CounsellorUtil.table(model);

    public ManageUsersForm(int userId, String fullName, String role) {

        this.userId = userId;

        setTitle("REbirth - Manage Users");
        FrameFit.maximize(this);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        table.getColumnModel().getColumn(0).setMaxWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(220);
        table.getColumnModel().getColumn(4).setPreferredWidth(120);
        table.getColumnModel().getColumn(5).setPreferredWidth(110);

        loading = true;
        try (Connection con = DBConnection.getConnection()) {
            roleCol = AdminUtil.roleColumn(con);
            List<String> roles = AdminUtil.roles(con, roleCol);
            for (String r : roles) {
                roleFilter.addItem(r);
                boolean have = false;
                for (int i = 0; i < roleBox.getItemCount(); i++) {
                    if (roleBox.getItemAt(i).equalsIgnoreCase(r)
                            || (AdminUtil.isAdmin(r)
                                && AdminUtil.isAdmin(roleBox.getItemAt(i)))) {
                        have = true;
                    }
                }
                if (!have) {
                    roleBox.addItem(r);
                }
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
        loading = false;

        JPanel root = new Theme.Backdrop(new BorderLayout());
        root.add(new Theme.HeaderBand("Manage Users",
            "Welcome, " + fullName + "  |  Role: " + role), BorderLayout.NORTH);

        JPanel card = CounsellorUtil.formCard();
        CounsellorUtil.addRow(card, 0, "Full Name", name);
        CounsellorUtil.addRow(card, 1, "Username", username);
        CounsellorUtil.addRow(card, 2, "Email", email);
        CounsellorUtil.addRow(card, 3, "Phone", phone);
        CounsellorUtil.addRow(card, 4, "Role", roleBox);
        CounsellorUtil.addRow(card, 5, "Password", password);
        CounsellorUtil.addRow(card, 6, "", Theme.text(
            "Password is used for Add User and Reset Password only. "
            + "Leave it empty when you update contact details.",
            620, 12, Theme.MUTED));

        Theme.Button go = new Theme.Button("Search", Theme.GREEN_DARK, Color.WHITE);
        go.addActionListener(e -> load());
        search.addActionListener(e -> load());
        roleFilter.addActionListener(e -> {
            if (!loading) {
                load();
            }
        });

        JPanel middle = new JPanel(new BorderLayout(0, 10));
        middle.setOpaque(false);
        middle.add(AdminUtil.searchRow(search, roleFilter, go), BorderLayout.NORTH);
        middle.add(CounsellorUtil.scroll(table), BorderLayout.CENTER);

        summary.setFont(Theme.f(Font.BOLD, 13));
        summary.setForeground(Theme.GREEN_DARK);
        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        south.add(buildButtons(), BorderLayout.WEST);
        south.add(summary, BorderLayout.EAST);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        body.add(card, BorderLayout.NORTH);
        body.add(middle, BorderLayout.CENTER);
        body.add(south, BorderLayout.SOUTH);

        root.add(FrameFit.scrollable(body), BorderLayout.CENTER);
        setContentPane(root);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFromRow();
            }
        });

        load();
    }

    private JPanel buildButtons() {

        Theme.Button add = new Theme.Button("Add User", Theme.GREEN, Color.WHITE);
        Theme.Button update = new Theme.Button("Update Selected",
            Theme.GREEN_DARK, Color.WHITE);
        Theme.Button reset = new Theme.Button("Reset Password",
            Theme.ORANGE, Color.WHITE);
        Theme.Button delete = new Theme.Button("Delete Selected",
            Theme.RED, Color.WHITE);
        Theme.Button clear = new Theme.Button("Clear",
            new Color(180, 120, 145), Color.WHITE);
        Theme.Button refresh = new Theme.Button("Refresh",
            new Color(120, 130, 150), Color.WHITE);

        add.addActionListener(e -> addUser());
        update.addActionListener(e -> updateUser());
        reset.addActionListener(e -> resetPassword());
        delete.addActionListener(e -> deleteUser());
        clear.addActionListener(e -> clearForm());
        refresh.addActionListener(e -> load());

        return CounsellorUtil.buttonRow(add, update, reset, delete, clear, refresh);
    }

    // ------------------------------------------------------------------
    private void load() {

        model.setRowCount(0);
        String filter = roleFilter.getSelectedItem() == null
            ? "All" : roleFilter.getSelectedItem().toString();
        String like = "%" + search.getText().trim().toUpperCase() + "%";
        int total = 0;

        String sql = "SELECT USER_ID, FULL_NAME, USERNAME, EMAIL, PHONE, "
            + roleCol + " FROM USERS "
            + "WHERE (? = 'All' OR UPPER(" + roleCol + ") = UPPER(?)) "
            + "AND (UPPER(NVL(FULL_NAME, ' ')) LIKE ? "
            + "OR UPPER(NVL(USERNAME, ' ')) LIKE ? "
            + "OR UPPER(NVL(EMAIL, ' ')) LIKE ?) "
            + "ORDER BY USER_ID";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, filter);
            ps.setString(2, filter);
            ps.setString(3, like);
            ps.setString(4, like);
            ps.setString(5, like);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        Theme.nz(rs.getString(4)), Theme.nz(rs.getString(5)),
                        rs.getString(6)
                    });
                }
            }
            try (Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM USERS")) {
                rs.next();
                total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
        summary.setText("Showing " + model.getRowCount() + " of " + total + " accounts");
        clearForm();
    }

    private void fillFromRow() {

        int row = table.getSelectedRow();
        if (row < 0) {
            return;
        }
        name.setText(String.valueOf(model.getValueAt(row, 1)));
        username.setText(String.valueOf(model.getValueAt(row, 2)));
        email.setText(String.valueOf(model.getValueAt(row, 3)));
        phone.setText(String.valueOf(model.getValueAt(row, 4)));
        roleBox.setSelectedItem(String.valueOf(model.getValueAt(row, 5)));
        password.setText("");
        username.setEditable(false);
        roleBox.setEnabled(false);
    }

    private void clearForm() {
        table.clearSelection();
        name.setText("");
        username.setText("");
        email.setText("");
        phone.setText("");
        password.setText("");
        roleBox.setSelectedIndex(0);
        username.setEditable(true);
        roleBox.setEnabled(true);
    }

    // ------------------------------------------------------------------
    private void addUser() {

        String role = String.valueOf(roleBox.getSelectedItem());
        if (!AdminUtil.isAdmin(role) && !AdminUtil.isNgo(role)) {
            CounsellorUtil.error(this, "Only Administrator and NGO accounts can be "
                + "created here. Prisoners and counsellors register themselves.");
            return;
        }
        String n = name.getText().trim();
        String u = username.getText().trim();
        String em = email.getText().trim();
        String ph = phone.getText().trim();
        String pw = new String(password.getPassword());

        String problem = AdminUtil.checkContact(n, em, ph);
        if (problem == null) {
            problem = AdminUtil.checkUsername(u);
        }
        if (problem == null) {
            problem = AdminUtil.checkPassword(pw);
        }
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            if (AdminUtil.usernameTaken(con, u)) {
                CounsellorUtil.error(this, "That username is already taken.");
                return;
            }
            AdminUtil.insertUser(con, roleCol, n, u, pw, em, ph, role);
            CounsellorUtil.info(this, "Account created for " + n + ".");
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void updateUser() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select a user from the table.");
            return;
        }
        String n = name.getText().trim();
        String em = email.getText().trim();
        String ph = phone.getText().trim();
        String problem = AdminUtil.checkContact(n, em, ph);
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }

        int id = (Integer) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            AdminUtil.updateContact(con, id, n, em, ph);
            CounsellorUtil.info(this, "User updated.");
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void resetPassword() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select a user from the table.");
            return;
        }
        String pw = new String(password.getPassword());
        String problem = AdminUtil.checkPassword(pw);
        if (problem != null) {
            CounsellorUtil.error(this, problem);
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this,
            "Set a new password for " + model.getValueAt(row, 1) + "?",
            "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        int id = (Integer) model.getValueAt(row, 0);
        try (Connection con = DBConnection.getConnection()) {
            AdminUtil.resetPassword(con, id, pw);
            password.setText("");
            CounsellorUtil.info(this, "Password changed.");
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private void deleteUser() {

        int row = table.getSelectedRow();
        if (row < 0) {
            CounsellorUtil.error(this, "Select a user from the table.");
            return;
        }
        int id = (Integer) model.getValueAt(row, 0);
        String role = String.valueOf(model.getValueAt(row, 5));

        if (id == userId) {
            CounsellorUtil.error(this, "You cannot delete your own account.");
            return;
        }
        if (!AdminUtil.isAdmin(role) && !AdminUtil.isNgo(role)) {
            CounsellorUtil.error(this, "Prisoner and counsellor accounts hold "
                + "case records and cannot be deleted from here.");
            return;
        }

        int ok = JOptionPane.showConfirmDialog(this,
            "Delete the account of " + model.getValueAt(row, 1) + "?",
            "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            if (AdminUtil.isAdmin(role) && AdminUtil.countAdmins(con, roleCol) <= 1) {
                CounsellorUtil.error(this, "This is the last administrator account.");
                return;
            }
            AdminUtil.deleteUser(con, id);
            load();
        } catch (SQLException ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }
}