package rebirth;

import java.awt.*;
import java.io.File;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Administrator report: one row per person, real numbers from the database.
 *
 *  Prisoners   : sessions attended, support requests, opportunities applied,
 *                schemes enrolled, documents held, goals done, readiness index
 *  Counsellors : sessions scheduled / completed / cancelled, notes written,
 *                prisoners served, goals set
 *
 * Click a column heading to sort. "Export CSV" opens in Excel.
 */
public class ReportsForm extends JFrame {

    private static final String[] PRISONER_COLS = {
        "Name", "District", "Sessions attended", "Sessions pending",
        "Support requests", "Requests pending", "Opportunities applied",
        "Opportunities completed", "Schemes enrolled", "Documents held (of 4)",
        "Documents applied", "Goals done", "Goals set", "Readiness index"
    };
    private static final String[] COUNSELLOR_COLS = {
        "Name", "Sessions scheduled", "Sessions completed", "Sessions cancelled",
        "Notes written", "Prisoners served", "Goals set"
    };

    private final CompassVisuals.KpiCard kAttended =
        new CompassVisuals.KpiCard("Sessions attended", CompassVisuals.D_NEON);
    private final CompassVisuals.KpiCard kApplied =
        new CompassVisuals.KpiCard("Opportunities applied", new Color(120, 200, 255));
    private final CompassVisuals.KpiCard kSchemes =
        new CompassVisuals.KpiCard("Schemes enrolled", new Color(200, 150, 255));
    private final CompassVisuals.KpiCard kDocs =
        new CompassVisuals.KpiCard("Documents held", new Color(255, 200, 90));
    private final CompassVisuals.KpiCard kPending =
        new CompassVisuals.KpiCard("Requests pending", new Color(255, 110, 110));

    private final DefaultTableModel prisonerModel = model(PRISONER_COLS);
    private final DefaultTableModel counsellorModel = model(COUNSELLOR_COLS);
    private final JTable prisonerTable = makeTable(prisonerModel, 2);
    private final JTable counsellorTable = makeTable(counsellorModel, 1);
    private final CardLayout cards = new CardLayout();
    private final JPanel holder = new JPanel(cards);
    private final JLabel status = new JLabel(" ");
    private String current = "prisoners";

    public ReportsForm(int userId, String fullName, String role) {

        setTitle("REbirth - Reports");
        FrameFit.maximize(this);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel root = new Theme.Backdrop(new BorderLayout());
        root.add(new Theme.HeaderBand("Reports",
            "Welcome, " + fullName + "  |  Role: " + role), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));

        JPanel kpis = new JPanel(new GridLayout(1, 5, 14, 0));
        kpis.setOpaque(false);
        kpis.setPreferredSize(new Dimension(100, 112));
        kpis.add(kAttended);
        kpis.add(kApplied);
        kpis.add(kSchemes);
        kpis.add(kDocs);
        kpis.add(kPending);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setOpaque(false);
        ButtonGroup g = new ButtonGroup();
        Theme.Chip pc = new Theme.Chip("Prisoners");
        Theme.Chip cc = new Theme.Chip("Counsellors");
        pc.setSelected(true);
        g.add(pc);
        g.add(cc);
        pc.addActionListener(e -> show("prisoners"));
        cc.addActionListener(e -> show("counsellors"));
        Theme.Button refresh = new Theme.Button("Refresh", new Color(120, 130, 150), Color.WHITE);
        Theme.Button export = new Theme.Button("Export CSV", Theme.GREEN, Color.WHITE);
        refresh.addActionListener(e -> load());
        export.addActionListener(e -> exportCsv());
        status.setFont(Theme.f(Font.PLAIN, 12));
        status.setForeground(Theme.MUTED);
        bar.add(pc);
        bar.add(cc);
        bar.add(refresh);
        bar.add(export);
        bar.add(status);

        JPanel top = new JPanel(new BorderLayout(0, 12));
        top.setOpaque(false);
        top.add(kpis, BorderLayout.NORTH);
        top.add(bar, BorderLayout.SOUTH);
        body.add(top, BorderLayout.NORTH);

        holder.setOpaque(false);
        holder.add(CounsellorUtil.scroll(prisonerTable), "prisoners");
        holder.add(CounsellorUtil.scroll(counsellorTable), "counsellors");
        body.add(holder, BorderLayout.CENTER);

        JLabel note = new JLabel("<html><body style='width:1000px'>Every number is counted from "
            + "the database. \"Sessions attended\" = completed sessions. Documents are the four "
            + "tracked in the checklist (ID proof, bank account, address proof, certificates). "
            + "This report shows names: share it only with authorised staff.</body></html>");
        note.setFont(Theme.f(Font.PLAIN, 11));
        note.setForeground(Theme.MUTED);
        body.add(note, BorderLayout.SOUTH);

        root.add(FrameFit.scrollable(body), BorderLayout.CENTER);
        setContentPane(root);
        load();
    }

    // ------------------------------------------------------------------
    private static DefaultTableModel model(String[] cols) {
        return new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int c) {
                return c == 0 || (cols.length > 10 && c == 1) ? String.class : Integer.class;
            }
        };
    }

    private static JTable makeTable(DefaultTableModel m, int firstNumber) {

        JTable t = CounsellorUtil.table(m);
        t.setAutoCreateRowSorter(true);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        t.getTableHeader().setPreferredSize(new Dimension(100, 50));

        DefaultTableCellRenderer head = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v,
                    boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, sel, foc, r, c);
                setText("<html><div style='text-align:center'>"
                    + String.valueOf(v).replace(" (", "<br>(").replaceFirst(" ", "<br>")
                    + "</div></html>");
                setHorizontalAlignment(c >= firstNumber ? CENTER : LEFT);
                setBackground(Theme.GREEN);
                setForeground(Color.WHITE);
                setFont(Theme.f(Font.BOLD, 12));
                setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                return this;
            }
        };
        t.getTableHeader().setDefaultRenderer(head);

        DefaultTableCellRenderer cell = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v,
                    boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, sel, false, r, c);
                setBackground(sel ? Theme.GREEN_SOFT
                    : (r % 2 == 0 ? Color.WHITE : new Color(244, 250, 246)));
                setForeground(Theme.TEXT);
                setHorizontalAlignment(c >= firstNumber ? CENTER : LEFT);
                setFont(Theme.f(c == 0 ? Font.BOLD : Font.PLAIN, 13));
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return this;
            }
        };
        t.setDefaultRenderer(Object.class, cell);
        t.setDefaultRenderer(Integer.class, cell);
        t.setDefaultRenderer(String.class, cell);
        t.getColumnModel().getColumn(0).setPreferredWidth(170);
        return t;
    }

    private void show(String which) {
        current = which;
        cards.show(holder, which);
    }

    // ------------------------------------------------------------------
    private void load() {

        status.setText("Counting from the database...");
        new SwingWorker<List<List<Object[]>>, Void>() {
            @Override
            protected List<List<Object[]>> doInBackground() throws Exception {
                try (Connection con = DBConnection.getConnection()) {
                    CounsellorUtil.ensureTables(con);
                    List<List<Object[]>> out = new ArrayList<>();
                    out.add(prisoners(con));
                    out.add(counsellors(con));
                    return out;
                }
            }

            @Override
            protected void done() {
                try {
                    apply(get());
                    status.setText(" ");
                } catch (Exception ex) {
                    status.setText(" ");
                    CounsellorUtil.error(ReportsForm.this, String.valueOf(
                        ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage()));
                }
            }
        }.execute();
    }

    private static String count(String table, String alias, String key, String extra) {
        return "(SELECT COUNT(*) FROM " + table + " " + alias + " WHERE " + alias + "."
            + key + " = p.PRISONER_ID" + extra + ")";
    }

    private static List<Object[]> prisoners(Connection con) throws SQLException {

        String sql = "SELECT p.PRISONER_ID, u.FULL_NAME, NVL(p.DISTRICT, ' '), "
            + count("COUNSELLING_SESSIONS", "s", "PRISONER_ID", " AND UPPER(s.STATUS) = 'COMPLETED'") + ", "
            + count("COUNSELLING_SESSIONS", "s", "PRISONER_ID", " AND UPPER(s.STATUS) = 'SCHEDULED'") + ", "
            + count("SUPPORT_REQUESTS", "r", "PRISONER_ID", "") + ", "
            + count("SUPPORT_REQUESTS", "r", "PRISONER_ID", " AND UPPER(r.STATUS) = 'PENDING'") + ", "
            + count("OPPORTUNITY_APPLICATIONS", "a", "PRISONER_ID", "") + ", "
            + count("OPPORTUNITY_APPLICATIONS", "a", "PRISONER_ID", " AND UPPER(a.STATUS) = 'COMPLETED'") + ", "
            + count("SCHEME_ENROLLMENTS", "e", "PRISONER_ID", "") + ", "
            + count("DOCUMENT_STATUS", "d", "PRISONER_ID", " AND UPPER(d.STATUS) = 'HELD'") + ", "
            + count("DOCUMENT_STATUS", "d", "PRISONER_ID", " AND UPPER(d.STATUS) = 'APPLIED'") + ", "
            + count("REHABILITATION_PLANS", "g", "PRISONER_ID", " AND UPPER(g.STATUS) = 'COMPLETED'") + ", "
            + count("REHABILITATION_PLANS", "g", "PRISONER_ID", "")
            + " FROM PRISONER_DETAILS p JOIN USERS u ON u.USER_ID = p.USER_ID "
            + "ORDER BY u.FULL_NAME";

        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int pid = rs.getInt(1);
                double idx = 0;
                try {
                    idx = CompassEngine.compute(con, pid).index;
                } catch (SQLException ignored) {
                    // leave 0
                }
                rows.add(new Object[]{
                    rs.getString(2), rs.getString(3).trim(),
                    rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7),
                    rs.getInt(8), rs.getInt(9), rs.getInt(10), rs.getInt(11),
                    rs.getInt(12), rs.getInt(13), rs.getInt(14), (int) Math.round(idx)});
            }
        }
        return rows;
    }

    private static List<Object[]> counsellors(Connection con) throws SQLException {

        String c = "(SELECT COUNT(*) FROM COUNSELLING_SESSIONS s WHERE s.COUNSELLOR_ID = c.COUNSELLOR_ID";
        String sql = "SELECT u.FULL_NAME, "
            + c + " AND UPPER(s.STATUS) = 'SCHEDULED'), "
            + c + " AND UPPER(s.STATUS) = 'COMPLETED'), "
            + c + " AND UPPER(s.STATUS) = 'CANCELLED'), "
            + c + " AND s.NOTES IS NOT NULL AND DBMS_LOB.GETLENGTH(s.NOTES) > 0), "
            + "(SELECT COUNT(DISTINCT s.PRISONER_ID) FROM COUNSELLING_SESSIONS s "
            + "WHERE s.COUNSELLOR_ID = c.COUNSELLOR_ID), "
            + "(SELECT COUNT(*) FROM REHABILITATION_PLANS g WHERE g.COUNSELLOR_ID = c.COUNSELLOR_ID) "
            + "FROM COUNSELLOR_DETAILS c JOIN USERS u ON u.USER_ID = c.USER_ID "
            + "ORDER BY u.FULL_NAME";

        List<Object[]> rows = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                rows.add(new Object[]{rs.getString(1), rs.getInt(2), rs.getInt(3),
                    rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7)});
            }
        }
        return rows;
    }

    private void apply(List<List<Object[]>> data) {

        prisonerModel.setRowCount(0);
        counsellorModel.setRowCount(0);
        int attended = 0;
        int applied = 0;
        int schemes = 0;
        int docs = 0;
        int pending = 0;
        for (Object[] r : data.get(0)) {
            prisonerModel.addRow(r);
            attended += (Integer) r[2];
            pending += (Integer) r[5];
            applied += (Integer) r[6];
            schemes += (Integer) r[8];
            docs += (Integer) r[9];
        }
        for (Object[] r : data.get(1)) {
            counsellorModel.addRow(r);
        }
        kAttended.setValue(attended, "", "completed sessions");
        kApplied.setValue(applied, "", "applications");
        kSchemes.setValue(schemes, "", "enrolments");
        kDocs.setValue(docs, "", "of " + (data.get(0).size() * 4) + " tracked");
        kPending.setValue(pending, "", "awaiting a reply");
    }

    // ------------------------------------------------------------------
    private void exportCsv() {

        DefaultTableModel m = current.equals("prisoners") ? prisonerModel : counsellorModel;
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("rebirth_" + current + "_report.csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(
                new java.io.FileOutputStream(fc.getSelectedFile()), "UTF-8"))) {
            w.print('\uFEFF');
            StringBuilder h = new StringBuilder();
            for (int c = 0; c < m.getColumnCount(); c++) {
                h.append(c == 0 ? "" : ",").append(q(m.getColumnName(c)));
            }
            w.println(h);
            for (int r = 0; r < m.getRowCount(); r++) {
                StringBuilder line = new StringBuilder();
                for (int c = 0; c < m.getColumnCount(); c++) {
                    line.append(c == 0 ? "" : ",").append(q(String.valueOf(m.getValueAt(r, c))));
                }
                w.println(line);
            }
            CounsellorUtil.info(this, "Saved " + fc.getSelectedFile().getName());
        } catch (Exception ex) {
            CounsellorUtil.error(this, ex.getMessage());
        }
    }

    private static String q(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }
}